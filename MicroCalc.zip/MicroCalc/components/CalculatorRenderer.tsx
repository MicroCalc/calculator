'use client';

import React, { useState, useCallback } from 'react';
import { CalculatorSpec, CalculatorInput, CalculationResult } from '@/types/calculator';
import { executeCalculation } from '@/lib/formulas';
import { validateInputs, getDefaultValues } from '@/lib/calculators';
import { formatCurrency, formatNumber, formatPercentage, cn } from '@/lib/utils';

interface CalculatorRendererProps {
  spec: CalculatorSpec;
  compact?: boolean;
  onCalculate?: (result: CalculationResult) => void;
}

export default function CalculatorRenderer({ spec, compact = false, onCalculate }: CalculatorRendererProps) {
  const [values, setValues] = useState<Record<string, string | number>>(() => getDefaultValues(spec));
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [result, setResult] = useState<CalculationResult | null>(null);
  const [isCalculating, setIsCalculating] = useState(false);

  const handleInputChange = useCallback((id: string, value: string | number) => {
    setValues(prev => ({ ...prev, [id]: value }));
    // Clear error when user starts typing
    if (errors[id]) {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[id];
        return newErrors;
      });
    }
  }, [errors]);

  const handleCalculate = useCallback(() => {
    // Validate inputs
    const validationErrors = validateInputs(spec, values);
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }

    setIsCalculating(true);
    setErrors({});

    // Execute calculation
    try {
      const calcResult = executeCalculation(spec.slug, values);
      setResult(calcResult);
      onCalculate?.(calcResult);
    } catch (error) {
      setResult({
        success: false,
        outputs: {},
        error: error instanceof Error ? error.message : 'Calculation failed',
      });
    } finally {
      setIsCalculating(false);
    }
  }, [spec, values, onCalculate]);

  const handleReset = useCallback(() => {
    setValues(getDefaultValues(spec));
    setErrors({});
    setResult(null);
  }, [spec]);

  const formatOutput = (value: number | string, output: typeof spec.outputs[0]): string => {
    if (typeof value === 'string') return value;
    
    const prefix = output.prefix || '';
    const suffix = output.suffix || '';
    
    switch (output.format) {
      case 'currency':
        return formatCurrency(value);
      case 'percentage':
        return formatPercentage(value, output.decimals || 2);
      case 'number':
        return prefix + formatNumber(value, output.decimals || 2) + suffix;
      default:
        return prefix + String(value) + suffix;
    }
  };

  const renderInput = (input: CalculatorInput) => {
    const error = errors[input.id];
    const value = values[input.id] ?? '';
    
    const baseInputClass = cn(
      'w-full px-4 py-3 rounded-lg border transition-all duration-200',
      'bg-white dark:bg-surface-800',
      'text-surface-900 dark:text-surface-100',
      'placeholder:text-surface-400 dark:placeholder:text-surface-500',
      error
        ? 'border-red-500 focus:border-red-500 focus:ring-red-500/20'
        : 'border-surface-200 dark:border-surface-700 focus:border-primary-500 focus:ring-primary-500/20',
      'focus:outline-none focus:ring-4'
    );

    const labelElement = (
      <label htmlFor={input.id} className="block text-sm font-medium text-surface-700 dark:text-surface-300 mb-2">
        {input.label}
        {input.validation?.required && <span className="text-red-500 ml-1">*</span>}
        {input.unit && <span className="text-surface-500 ml-1">({input.unit})</span>}
      </label>
    );

    const helpElement = input.helpText && (
      <p className="mt-1.5 text-xs text-surface-500 dark:text-surface-400">{input.helpText}</p>
    );

    const errorElement = error && (
      <p className="mt-1.5 text-xs text-red-500">{error}</p>
    );

    switch (input.type) {
      case 'select':
        return (
          <div key={input.id} className="space-y-1">
            {labelElement}
            <select
              id={input.id}
              value={String(value)}
              onChange={(e) => handleInputChange(input.id, e.target.value)}
              className={baseInputClass}
              aria-label={input.ariaLabel}
            >
              {input.options?.map((option) => (
                <option key={String(option.value)} value={String(option.value)}>
                  {option.label}
                </option>
              ))}
            </select>
            {helpElement}
            {errorElement}
          </div>
        );

      case 'radio':
        return (
          <div key={input.id} className="space-y-2">
            {labelElement}
            <div className="flex flex-wrap gap-3">
              {input.options?.map((option) => (
                <label
                  key={String(option.value)}
                  className={cn(
                    'flex items-center gap-2 px-4 py-2 rounded-lg border cursor-pointer transition-all',
                    String(value) === String(option.value)
                      ? 'border-primary-500 bg-primary-50 dark:bg-primary-900/20 text-primary-700 dark:text-primary-300'
                      : 'border-surface-200 dark:border-surface-700 hover:border-surface-300 dark:hover:border-surface-600'
                  )}
                >
                  <input
                    type="radio"
                    name={input.id}
                    value={String(option.value)}
                    checked={String(value) === String(option.value)}
                    onChange={(e) => handleInputChange(input.id, e.target.value)}
                    className="sr-only"
                  />
                  <span className="text-sm font-medium">{option.label}</span>
                </label>
              ))}
            </div>
            {helpElement}
            {errorElement}
          </div>
        );

      case 'date':
        return (
          <div key={input.id} className="space-y-1">
            {labelElement}
            <input
              type="date"
              id={input.id}
              value={String(value)}
              onChange={(e) => handleInputChange(input.id, e.target.value)}
              placeholder={input.placeholder}
              className={baseInputClass}
              aria-label={input.ariaLabel}
            />
            {helpElement}
            {errorElement}
          </div>
        );

      case 'range':
        return (
          <div key={input.id} className="space-y-2">
            {labelElement}
            <div className="flex items-center gap-4">
              <input
                type="range"
                id={input.id}
                value={Number(value)}
                onChange={(e) => handleInputChange(input.id, Number(e.target.value))}
                min={input.validation?.min || 0}
                max={input.validation?.max || 100}
                step={input.validation?.step || 1}
                className="flex-1 h-2 bg-surface-200 rounded-lg appearance-none cursor-pointer dark:bg-surface-700"
                aria-label={input.ariaLabel}
              />
              <span className="min-w-[3rem] text-center font-mono text-sm bg-surface-100 dark:bg-surface-800 px-2 py-1 rounded">
                {value}
              </span>
            </div>
            {helpElement}
            {errorElement}
          </div>
        );

      case 'currency':
      case 'percentage':
      case 'number':
      default:
        return (
          <div key={input.id} className="space-y-1">
            {labelElement}
            <div className="relative">
              {input.type === 'currency' && (
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-surface-500">$</span>
              )}
              <input
                type={input.type === 'text' ? 'text' : 'number'}
                id={input.id}
                value={value}
                onChange={(e) => handleInputChange(
                  input.id, 
                  input.type === 'text' ? e.target.value : Number(e.target.value)
                )}
                placeholder={input.placeholder}
                min={input.validation?.min}
                max={input.validation?.max}
                step={input.validation?.step || (input.type === 'percentage' ? 0.01 : 1)}
                className={cn(
                  baseInputClass,
                  input.type === 'currency' && 'pl-8',
                  input.type === 'percentage' && 'pr-8'
                )}
                aria-label={input.ariaLabel}
              />
              {input.type === 'percentage' && (
                <span className="absolute right-4 top-1/2 -translate-y-1/2 text-surface-500">%</span>
              )}
            </div>
            {helpElement}
            {errorElement}
          </div>
        );
    }
  };

  return (
    <div className={cn(
      'bg-white dark:bg-surface-900 rounded-2xl shadow-lg',
      compact ? 'p-4' : 'p-6 md:p-8'
    )}>
      {/* Input Section */}
      <div className={cn(
        'grid gap-5',
        compact ? 'grid-cols-1' : 'grid-cols-1 md:grid-cols-2'
      )}>
        {spec.inputs.map(renderInput)}
      </div>

      {/* Action Buttons */}
      <div className="flex flex-wrap gap-3 mt-6">
        <button
          onClick={handleCalculate}
          disabled={isCalculating}
          className={cn(
            'flex-1 min-w-[150px] px-6 py-3 rounded-xl font-semibold transition-all duration-200',
            'bg-gradient-to-r from-primary-500 to-primary-600 text-white',
            'hover:from-primary-600 hover:to-primary-700',
            'focus:outline-none focus:ring-4 focus:ring-primary-500/30',
            'disabled:opacity-50 disabled:cursor-not-allowed',
            'shadow-lg hover:shadow-xl transform hover:-translate-y-0.5'
          )}
        >
          {isCalculating ? (
            <span className="flex items-center justify-center gap-2">
              <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
              </svg>
              Calculating...
            </span>
          ) : (
            'Calculate'
          )}
        </button>
        <button
          onClick={handleReset}
          className={cn(
            'px-6 py-3 rounded-xl font-medium transition-all duration-200',
            'bg-surface-100 dark:bg-surface-800 text-surface-700 dark:text-surface-300',
            'hover:bg-surface-200 dark:hover:bg-surface-700',
            'focus:outline-none focus:ring-4 focus:ring-surface-500/20'
          )}
        >
          Reset
        </button>
      </div>

      {/* Results Section */}
      {result && (
        <div className={cn(
          'mt-8 p-6 rounded-xl',
          result.success
            ? 'bg-gradient-to-br from-primary-50 to-emerald-50 dark:from-primary-900/20 dark:to-emerald-900/20 border border-primary-200 dark:border-primary-800'
            : 'bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800'
        )}>
          {result.success ? (
            <>
              <h3 className="text-lg font-semibold text-surface-900 dark:text-surface-100 mb-4">
                Results
              </h3>
              <div className="grid gap-4">
                {spec.outputs.map((output) => {
                  const value = result.outputs[output.id];
                  if (value === undefined) return null;
                  
                  return (
                    <div
                      key={output.id}
                      className={cn(
                        'flex justify-between items-center p-4 rounded-lg',
                        output.highlight
                          ? 'bg-white dark:bg-surface-800 shadow-md'
                          : 'bg-white/50 dark:bg-surface-800/50'
                      )}
                    >
                      <span className="text-surface-600 dark:text-surface-400 font-medium">
                        {output.label}
                      </span>
                      <span className={cn(
                        'font-bold',
                        output.highlight
                          ? 'text-2xl text-primary-600 dark:text-primary-400'
                          : 'text-lg text-surface-900 dark:text-surface-100'
                      )}>
                        {formatOutput(value, output)}
                      </span>
                    </div>
                  );
                })}
              </div>

              {/* Breakdown */}
              {result.breakdown && result.breakdown.length > 0 && (
                <div className="mt-6 pt-6 border-t border-surface-200 dark:border-surface-700">
                  <h4 className="text-sm font-semibold text-surface-600 dark:text-surface-400 mb-3 uppercase tracking-wider">
                    Breakdown
                  </h4>
                  <div className="space-y-2">
                    {result.breakdown.map((item, index) => (
                      <div
                        key={index}
                        className="flex justify-between text-sm py-1.5 border-b border-surface-100 dark:border-surface-800 last:border-0"
                      >
                        <span className="text-surface-600 dark:text-surface-400">{item.label}</span>
                        <span className="font-medium text-surface-900 dark:text-surface-100">
                          {item.value}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </>
          ) : (
            <div className="flex items-center gap-3 text-red-600 dark:text-red-400">
              <svg className="w-6 h-6 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
              </svg>
              <span>{result.error || 'An error occurred during calculation'}</span>
            </div>
          )}
        </div>
      )}

      {/* Not Implemented Notice */}
      {!spec.implemented && (
        <div className="mt-4 p-4 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-lg">
          <div className="flex items-center gap-2 text-amber-700 dark:text-amber-300">
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <span className="text-sm font-medium">
              This calculator is coming soon! The formula and inputs are defined but the calculation logic is pending.
            </span>
          </div>
        </div>
      )}
    </div>
  );
}

