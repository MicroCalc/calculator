'use client';

import React, { useState } from 'react';
import { cn, copyToClipboard, generateEmbedCode, getBaseUrl } from '@/lib/utils';

interface EmbedCodeProps {
  slug: string;
  title: string;
  className?: string;
}

export default function EmbedCode({ slug, title, className }: EmbedCodeProps) {
  const [width, setWidth] = useState(400);
  const [height, setHeight] = useState(600);
  const [copied, setCopied] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);

  const baseUrl = getBaseUrl();
  const embedCode = generateEmbedCode(slug, baseUrl, width, height);

  const handleCopy = async () => {
    const success = await copyToClipboard(embedCode);
    if (success) {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className={cn('rounded-xl bg-surface-50 dark:bg-surface-800 overflow-hidden', className)}>
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-full flex items-center justify-between p-4 hover:bg-surface-100 dark:hover:bg-surface-700 transition-colors"
      >
        <div className="flex items-center gap-3">
          <svg className="w-5 h-5 text-primary-600 dark:text-primary-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" />
          </svg>
          <span className="font-medium text-surface-900 dark:text-surface-100">
            Embed This Calculator
          </span>
        </div>
        <svg
          className={cn(
            'w-5 h-5 text-surface-500 transition-transform',
            isExpanded && 'rotate-180'
          )}
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
        >
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
        </svg>
      </button>

      {isExpanded && (
        <div className="p-4 pt-0 space-y-4 animate-slide-down">
          <p className="text-sm text-surface-600 dark:text-surface-400">
            Add this calculator to your website or blog with the embed code below.
          </p>

          {/* Size Controls */}
          <div className="flex gap-4">
            <div className="flex-1">
              <label className="block text-xs font-medium text-surface-600 dark:text-surface-400 mb-1">
                Width (px)
              </label>
              <input
                type="number"
                value={width}
                onChange={(e) => setWidth(Number(e.target.value))}
                min={300}
                max={1200}
                className="w-full px-3 py-2 text-sm rounded-lg border border-surface-200 dark:border-surface-700 bg-white dark:bg-surface-900 focus:outline-none focus:ring-2 focus:ring-primary-500/50"
              />
            </div>
            <div className="flex-1">
              <label className="block text-xs font-medium text-surface-600 dark:text-surface-400 mb-1">
                Height (px)
              </label>
              <input
                type="number"
                value={height}
                onChange={(e) => setHeight(Number(e.target.value))}
                min={400}
                max={1200}
                className="w-full px-3 py-2 text-sm rounded-lg border border-surface-200 dark:border-surface-700 bg-white dark:bg-surface-900 focus:outline-none focus:ring-2 focus:ring-primary-500/50"
              />
            </div>
          </div>

          {/* Code Preview */}
          <div className="relative">
            <pre className="p-4 bg-surface-900 dark:bg-surface-950 text-surface-300 text-xs rounded-lg overflow-x-auto">
              <code>{embedCode}</code>
            </pre>
            <button
              onClick={handleCopy}
              className={cn(
                'absolute top-2 right-2 px-3 py-1.5 rounded-lg text-xs font-medium',
                'transition-all duration-200',
                copied
                  ? 'bg-green-500 text-white'
                  : 'bg-surface-700 hover:bg-surface-600 text-surface-200'
              )}
            >
              {copied ? 'Copied!' : 'Copy'}
            </button>
          </div>

          {/* Preview */}
          <div>
            <label className="block text-xs font-medium text-surface-600 dark:text-surface-400 mb-2">
              Preview
            </label>
            <div className="border border-surface-200 dark:border-surface-700 rounded-lg overflow-hidden bg-white dark:bg-surface-900">
              <iframe
                src={`/embed/${slug}`}
                width={Math.min(width, 500)}
                height={Math.min(height, 400)}
                frameBorder="0"
                title={`${title} Preview`}
                className="mx-auto"
              />
            </div>
          </div>

          {/* Usage Note */}
          <div className="flex items-start gap-2 text-xs text-surface-500 dark:text-surface-400">
            <svg className="w-4 h-4 flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <span>
              By embedding this calculator, you agree to our{' '}
              <a href="/terms" className="text-primary-600 dark:text-primary-400 hover:underline">
                terms of service
              </a>
              . Attribution to MicroCalc is appreciated but not required.
            </span>
          </div>
        </div>
      )}
    </div>
  );
}

