'use client'

import { AD_SIZES } from '@/lib/constants'

type AdSize = keyof typeof AD_SIZES

interface AdPlaceholderProps {
  size?: AdSize
  className?: string
  slot?: string
}

/**
 * AdSense Placeholder Component
 * 
 * This component displays a placeholder for Google AdSense ads.
 * Replace the placeholder with actual AdSense code once you have
 * your publisher ID and ad unit IDs.
 * 
 * Setup Instructions:
 * 1. Sign up for Google AdSense at https://www.google.com/adsense/
 * 2. Get approved and create ad units
 * 3. Add your publisher ID to environment variables:
 *    NEXT_PUBLIC_ADSENSE_PUBLISHER_ID=ca-pub-XXXXXXXXXXXXXXXX
 * 4. Replace the placeholder content with the AdSense script/code
 * 
 * Example AdSense integration:
 * ```tsx
 * <Script
 *   async
 *   src={`https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${publisherId}`}
 *   crossOrigin="anonymous"
 * />
 * <ins
 *   className="adsbygoogle"
 *   style={{ display: 'block' }}
 *   data-ad-client={publisherId}
 *   data-ad-slot={slot}
 *   data-ad-format="auto"
 *   data-full-width-responsive="true"
 * />
 * ```
 */
export function AdPlaceholder({ size = 'rectangle', className = '', slot }: AdPlaceholderProps) {
  const dimensions = AD_SIZES[size]
  const publisherId = process.env.NEXT_PUBLIC_ADSENSE_PUBLISHER_ID

  // If AdSense is configured, render actual ad
  // TODO: Implement actual AdSense integration when publisher ID is available
  // if (publisherId && slot) {
  //   return <ActualAdSenseComponent publisherId={publisherId} slot={slot} />
  // }

  return (
    <div
      className={`relative bg-[var(--color-bg-tertiary)] border border-dashed border-[var(--color-border)] rounded-lg overflow-hidden ${className}`}
      style={{
        width: '100%',
        maxWidth: dimensions.width,
        aspectRatio: `${dimensions.width} / ${dimensions.height}`,
      }}
      aria-label="Advertisement placeholder"
      role="complementary"
    >
      <div className="absolute inset-0 flex flex-col items-center justify-center text-[var(--color-text-muted)] p-4">
        <svg
          className="w-8 h-8 mb-2 opacity-50"
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={1.5}
            d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"
          />
        </svg>
        <span className="text-xs font-medium opacity-75">Advertisement</span>
        <span className="text-xs opacity-50 mt-1">
          {dimensions.width} × {dimensions.height}
        </span>
      </div>
      
      {/* Pattern overlay for visual interest */}
      <div 
        className="absolute inset-0 opacity-5 pointer-events-none"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='20' height='20' viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%23000' fill-opacity='1' fill-rule='evenodd'%3E%3Ccircle cx='3' cy='3' r='1.5'/%3E%3Ccircle cx='13' cy='13' r='1.5'/%3E%3C/g%3E%3C/svg%3E")`,
        }}
      />
    </div>
  )
}

/**
 * Responsive ad that adjusts to container width
 */
export function ResponsiveAd({ className = '' }: { className?: string }) {
  return (
    <div className={`w-full ${className}`}>
      {/* Mobile ad */}
      <div className="block md:hidden">
        <AdPlaceholder size="mobile" className="mx-auto" />
      </div>
      {/* Desktop ad */}
      <div className="hidden md:block lg:hidden">
        <AdPlaceholder size="banner" className="mx-auto" />
      </div>
      {/* Large desktop ad */}
      <div className="hidden lg:block">
        <AdPlaceholder size="leaderboard" className="mx-auto" />
      </div>
    </div>
  )
}

/**
 * Sidebar ad component
 */
export function SidebarAd({ className = '' }: { className?: string }) {
  return (
    <div className={`sticky top-24 ${className}`}>
      <AdPlaceholder size="rectangle" className="mx-auto" />
    </div>
  )
}

