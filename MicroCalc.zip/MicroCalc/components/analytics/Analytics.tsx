'use client'

import Script from 'next/script'

/**
 * Analytics Component
 * 
 * Handles Google Analytics 4 integration.
 * 
 * Setup Instructions:
 * 1. Go to Google Analytics (analytics.google.com)
 * 2. Create a new property for your site
 * 3. Go to Admin > Data Streams > Add stream > Web
 * 4. Copy the Measurement ID (starts with G-)
 * 5. Add to your environment variables:
 *    NEXT_PUBLIC_GA4_MEASUREMENT_ID=G-XXXXXXXXXX
 */
export function Analytics() {
  const gaId = process.env.NEXT_PUBLIC_GA4_MEASUREMENT_ID

  // Don't render anything if no GA ID is configured
  if (!gaId) {
    return null
  }

  return (
    <>
      {/* Google Analytics 4 */}
      <Script
        src={`https://www.googletagmanager.com/gtag/js?id=${gaId}`}
        strategy="afterInteractive"
      />
      <Script id="google-analytics" strategy="afterInteractive">
        {`
          window.dataLayer = window.dataLayer || [];
          function gtag(){dataLayer.push(arguments);}
          gtag('js', new Date());
          gtag('config', '${gaId}', {
            page_path: window.location.pathname,
            anonymize_ip: true,
            cookie_flags: 'SameSite=None;Secure',
          });
        `}
      </Script>
    </>
  )
}

/**
 * Track custom events
 * Call this function to track specific user actions
 * 
 * @example
 * trackEvent('calculator_used', { calculator: 'mortgage', result: 1500 })
 */
export function trackEvent(
  eventName: string,
  eventParams?: Record<string, string | number | boolean>
) {
  if (typeof window !== 'undefined' && (window as any).gtag) {
    ;(window as any).gtag('event', eventName, eventParams)
  }
}

/**
 * Track calculator usage
 * Convenience function for tracking calculator events
 */
export function trackCalculatorUsage(calculatorSlug: string, action: 'view' | 'calculate' | 'share' | 'embed') {
  trackEvent('calculator_action', {
    calculator: calculatorSlug,
    action: action,
  })
}

/**
 * Track search events
 */
export function trackSearch(searchTerm: string, resultsCount: number) {
  trackEvent('search', {
    search_term: searchTerm,
    results_count: resultsCount,
  })
}

