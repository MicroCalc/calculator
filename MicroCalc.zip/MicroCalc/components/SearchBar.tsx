'use client';

import React, { useState, useCallback, useRef, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { searchCalculators } from '@/lib/calculators';
import { SearchResult } from '@/types/calculator';
import { cn, debounce } from '@/lib/utils';
import { CATEGORY_COLORS } from '@/lib/constants';

interface SearchBarProps {
  compact?: boolean;
  onSearch?: () => void;
}

export default function SearchBar({ compact = false, onSearch }: SearchBarProps) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(-1);
  const inputRef = useRef<HTMLInputElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const router = useRouter();

  // Debounced search
  const performSearch = useCallback(
    debounce((searchQuery: string) => {
      if (searchQuery.trim().length < 2) {
        setResults([]);
        return;
      }
      const searchResults = searchCalculators(searchQuery, 8);
      setResults(searchResults);
      setIsOpen(searchResults.length > 0);
      setSelectedIndex(-1);
    }, 150),
    []
  );

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setQuery(value);
    performSearch(value);
  };

  const handleResultClick = (slug: string) => {
    router.push(`/calculators/${slug}`);
    setQuery('');
    setResults([]);
    setIsOpen(false);
    onSearch?.();
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (!isOpen) return;

    switch (e.key) {
      case 'ArrowDown':
        e.preventDefault();
        setSelectedIndex((prev) => (prev < results.length - 1 ? prev + 1 : prev));
        break;
      case 'ArrowUp':
        e.preventDefault();
        setSelectedIndex((prev) => (prev > 0 ? prev - 1 : -1));
        break;
      case 'Enter':
        e.preventDefault();
        if (selectedIndex >= 0 && results[selectedIndex]) {
          handleResultClick(results[selectedIndex].slug);
        } else if (query.trim()) {
          router.push(`/search?q=${encodeURIComponent(query)}`);
          setIsOpen(false);
          onSearch?.();
        }
        break;
      case 'Escape':
        setIsOpen(false);
        setSelectedIndex(-1);
        break;
    }
  };

  // Close on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div ref={containerRef} className="relative">
      <div className="relative">
        <input
          ref={inputRef}
          type="text"
          value={query}
          onChange={handleInputChange}
          onKeyDown={handleKeyDown}
          onFocus={() => results.length > 0 && setIsOpen(true)}
          placeholder="Search calculators..."
          className={cn(
            'w-full rounded-xl border border-surface-200 dark:border-surface-700',
            'bg-surface-50 dark:bg-surface-800',
            'text-surface-900 dark:text-surface-100',
            'placeholder:text-surface-400 dark:placeholder:text-surface-500',
            'focus:outline-none focus:ring-2 focus:ring-primary-500/50 focus:border-primary-500',
            'transition-all duration-200',
            compact ? 'px-4 py-2 text-sm pr-9' : 'px-5 py-3 pr-11'
          )}
          aria-label="Search calculators"
          aria-expanded={isOpen}
          aria-controls="search-results"
          role="combobox"
        />
        <svg
          className={cn(
            'absolute top-1/2 -translate-y-1/2 text-surface-400',
            compact ? 'right-3 w-4 h-4' : 'right-4 w-5 h-5'
          )}
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
        >
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
        </svg>
      </div>

      {/* Results Dropdown */}
      {isOpen && (
        <div
          id="search-results"
          className={cn(
            'absolute top-full left-0 right-0 mt-2 py-2',
            'bg-white dark:bg-surface-800 rounded-xl shadow-xl',
            'border border-surface-200 dark:border-surface-700',
            'max-h-96 overflow-y-auto z-50',
            'animate-slide-down'
          )}
          role="listbox"
        >
          {results.map((result, index) => (
            <button
              key={result.slug}
              onClick={() => handleResultClick(result.slug)}
              className={cn(
                'w-full px-4 py-3 text-left transition-colors',
                'flex items-start gap-3',
                index === selectedIndex
                  ? 'bg-primary-50 dark:bg-primary-900/20'
                  : 'hover:bg-surface-50 dark:hover:bg-surface-700'
              )}
              role="option"
              aria-selected={index === selectedIndex}
            >
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-0.5">
                  <span className="font-medium text-surface-900 dark:text-surface-100 truncate">
                    {result.name}
                  </span>
                  <span className={cn(
                    'text-xs px-2 py-0.5 rounded-full',
                    CATEGORY_COLORS[result.category]
                  )}>
                    {result.category}
                  </span>
                </div>
                <p className="text-sm text-surface-500 dark:text-surface-400 truncate">
                  {result.description}
                </p>
              </div>
              <svg
                className="w-5 h-5 text-surface-400 flex-shrink-0 mt-0.5"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </button>
          ))}
          
          {query.trim().length >= 2 && (
            <button
              onClick={() => {
                router.push(`/search?q=${encodeURIComponent(query)}`);
                setIsOpen(false);
                onSearch?.();
              }}
              className="w-full px-4 py-3 text-left text-sm text-primary-600 dark:text-primary-400 hover:bg-surface-50 dark:hover:bg-surface-700 transition-colors border-t border-surface-200 dark:border-surface-700"
            >
              See all results for &quot;{query}&quot; →
            </button>
          )}
        </div>
      )}
    </div>
  );
}

