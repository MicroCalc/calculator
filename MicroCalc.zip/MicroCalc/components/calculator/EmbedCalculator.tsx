'use client'

import { useState, useCallback, useMemo } from 'react'
import type { CalculatorSpec, CalculatorInput, CalculatorResult } from '@/types'
import { executeFormula } from '@/lib/formulas'

interface EmbedCalculatorProps {
  spec: CalculatorSpec
}

/**
 * Minimal calculator component for embedding in external sites
 */
export function EmbedCalculator({ spec }: EmbedCalculatorProps) {
  const initialInputs = useMemo(() => {
    const values: Record<string, string | number> = {}
    spec.inputs.forEach((input) => {
      values[input.id] = input.defaultValue ?? ''
    })
    return values
  }, [spec.inputs])

  const [inputs, setInputs] = useState<Record<string, string | number>>(initialInputs)
  const [result, setResult] = useState<CalculatorResult | null>(null)
  const [isCalculating, setIsCalculating] = useState(false)

  const handleInputChange = useCallback((id: string, value: string | number) => {
    setInputs((prev) => ({ ...prev, [id]: value }))
  }, [])

  const handleCalculate = useCallback(() => {
    setIsCalculating(true)
    setTimeout(() => {
      const calcResult = executeFormula(spec.formulaId, inputs)
      setResult(calcResult)
      setIsCalculating(false)
    }, 100)
  }, [inputs, spec.formulaId])

  const handleReset = useCallback(() => {
    setInputs(initialInputs)
    setResult(null)
  }, [initialInputs])

  const shouldShowInput = (input: CalculatorInput): boolean => {
    if (!input.showWhen) return true
    return inputs[input.showWhen.inputId] === input.showWhen.value
  }

  const renderInput = (input: CalculatorInput) => {
    if (!shouldShowInput(input)) return null
    const value = inputs[input.id]

    switch (input.type) {
      case 'select':
        return (
          <div key={input.id} className="mb-3">
            <label className="block text-xs font-medium mb-1">{input.label}</label>
            <select
              value={value}
              onChange={(e) => handleInputChange(input.id, e.target.value)}
              className="w-full px-3 py-2 text-sm border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 outline-none"
            >
              {input.options?.map((opt) => (
                <option key={opt.value} value={opt.value}>{opt.label}</option>
              ))}
            </select>
          </div>
        )

      case 'radio':
        return (
          <div key={input.id} className="mb-3">
            <label className="block text-xs font-medium mb-1">{input.label}</label>
            <div className="flex flex-wrap gap-2">
              {input.options?.map((opt) => (
                <label
                  key={opt.value}
                  className={`px-3 py-1 text-xs rounded-full cursor-pointer border transition-colors ${
                    value === opt.value
                      ? 'border-primary-500 bg-primary-50 text-primary-700'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <input
                    type="radio"
                    name={input.id}
                    value={opt.value}
                    checked={value === opt.value}
                    onChange={(e) => handleInputChange(input.id, e.target.value)}
                    className="sr-only"
                  />
                  {opt.label}
                </label>
              ))}
            </div>
          </div>
        )

      case 'date':
        return (
          <div key={input.id} className="mb-3">
            <label className="block text-xs font-medium mb-1">{input.label}</label>
            <input
              type="date"
              value={value as string}
              onChange={(e) => handleInputChange(input.id, e.target.value)}
              className="w-full px-3 py-2 text-sm border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 outline-none"
            />
          </div>
        )

      default:
        return (
          <div key={input.id} className="mb-3">
            <label className="block text-xs font-medium mb-1">{input.label}</label>
            <div className="relative">
              {input.unit && input.unitPosition === 'prefix' && (
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm">
                  {input.unit}
                </span>
              )}
              <input
                type={input.type === 'text' ? 'text' : 'number'}
                value={value}
                onChange={(e) => handleInputChange(input.id, e.target.value)}
                placeholder={input.placeholder}
                className={`w-full px-3 py-2 text-sm border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 outline-none ${
                  input.unitPosition === 'prefix' ? 'pl-8' : ''
                } ${input.unitPosition === 'suffix' ? 'pr-12' : ''}`}
              />
              {input.unit && input.unitPosition === 'suffix' && (
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm">
                  {input.unit}
                </span>
              )}
            </div>
          </div>
        )
    }
  }

  return (
    <div className="bg-white dark:bg-gray-900 rounded-lg border border-gray-200 dark:border-gray-700 p-4 max-w-md mx-auto">
      {/* Header */}
      <div className="flex items-center gap-2 mb-4 pb-3 border-b border-gray-100 dark:border-gray-800">
        <span className="text-xl">{spec.icon}</span>
        <h2 className="font-semibold text-gray-900 dark:text-white text-sm">
          {spec.title}
        </h2>
      </div>

      {/* Inputs */}
      <div className="mb-4">
        {spec.inputs.slice(0, 6).map(renderInput)}
      </div>

      {/* Buttons */}
      <div className="flex gap-2 mb-4">
        <button
          onClick={handleCalculate}
          disabled={isCalculating}
          className="flex-1 px-4 py-2 text-sm font-medium text-white bg-primary-500 rounded-lg hover:bg-primary-600 disabled:opacity-50 transition-colors"
        >
          {isCalculating ? 'Calculating...' : 'Calculate'}
        </button>
        <button
          onClick={handleReset}
          className="px-4 py-2 text-sm font-medium text-gray-600 dark:text-gray-300 bg-gray-100 dark:bg-gray-800 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
        >
          Reset
        </button>
      </div>

      {/* Results */}
      {result?.success && (
        <div className="bg-primary-50 dark:bg-primary-900/30 rounded-lg p-4">
          {spec.outputs.filter(o => o.highlight).map((output) => {
            const value = result.outputs[output.id]
            let displayValue: string

            switch (output.format) {
              case 'currency':
                displayValue = `$${Number(value).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`
                break
              case 'percentage':
                displayValue = `${Number(value).toFixed(1)}%`
                break
              default:
                displayValue = String(value)
            }

            return (
              <div key={output.id}>
                <p className="text-xs text-primary-600 dark:text-primary-400 mb-1">{output.label}</p>
                <p className="text-2xl font-bold text-primary-700 dark:text-primary-300 font-mono">
                  {displayValue}
                </p>
              </div>
            )
          })}
        </div>
      )}

      {result && !result.success && (
        <div className="bg-red-50 dark:bg-red-900/30 rounded-lg p-3">
          <p className="text-sm text-red-600 dark:text-red-400">{result.error}</p>
        </div>
      )}

      {/* Powered by */}
      <div className="mt-4 pt-3 border-t border-gray-100 dark:border-gray-800 text-center">
        <a
          href={process.env.NEXT_PUBLIC_SITE_URL || 'https://microcalc.app'}
          target="_blank"
          rel="noopener noreferrer"
          className="text-xs text-gray-400 hover:text-primary-500 transition-colors"
        >
          Powered by MicroCalc
        </a>
      </div>
    </div>
  )
}

