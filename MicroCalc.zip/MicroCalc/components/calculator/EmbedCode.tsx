'use client'

import { useState } from 'react'
import { trackCalculatorUsage } from '@/components/analytics/Analytics'

interface EmbedCodeProps {
  slug: string
  title: string
}

export function EmbedCode({ slug, title }: EmbedCodeProps) {
  const [isExpanded, setIsExpanded] = useState(false)
  const [copied, setCopied] = useState(false)

  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || 'https://microcalc.app'
  const embedUrl = `${siteUrl}/embed/${slug}`

  const iframeCode = `<iframe 
  src="${embedUrl}" 
  width="100%" 
  height="500" 
  style="border: 1px solid #e5e7eb; border-radius: 8px;" 
  title="${title}"
  loading="lazy"
  allow="clipboard-write"
></iframe>

<!-- Powered by MicroCalc - ${siteUrl} -->`

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(iframeCode)
      setCopied(true)
      trackCalculatorUsage(slug, 'embed')
      setTimeout(() => setCopied(false), 2000)
    } catch (err) {
      console.error('Failed to copy:', err)
    }
  }

  return (
    <div className="card">
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="flex items-center justify-between w-full text-left"
        aria-expanded={isExpanded}
      >
        <div className="flex items-center gap-2">
          <svg className="w-5 h-5 text-[var(--color-text-muted)]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" />
          </svg>
          <span className="font-medium text-[var(--color-text-primary)]">Embed This Calculator</span>
        </div>
        <svg 
          className={`w-5 h-5 text-[var(--color-text-muted)] transition-transform ${isExpanded ? 'rotate-180' : ''}`} 
          fill="none" 
          stroke="currentColor" 
          viewBox="0 0 24 24"
        >
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
        </svg>
      </button>

      {isExpanded && (
        <div className="mt-4 animate-fade-in">
          <p className="text-sm text-[var(--color-text-secondary)] mb-3">
            Copy the code below to embed this calculator on your website or blog:
          </p>
          
          <div className="relative">
            <pre className="bg-[var(--color-bg-tertiary)] rounded-lg p-4 text-sm overflow-x-auto font-mono text-[var(--color-text-secondary)]">
              {iframeCode}
            </pre>
            
            <button
              onClick={handleCopy}
              className={`absolute top-2 right-2 px-3 py-1.5 text-sm rounded-md transition-colors ${
                copied
                  ? 'bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300'
                  : 'bg-primary-100 text-primary-700 dark:bg-primary-900 dark:text-primary-300 hover:bg-primary-200 dark:hover:bg-primary-800'
              }`}
            >
              {copied ? '✓ Copied!' : 'Copy'}
            </button>
          </div>

          <div className="mt-4 p-4 bg-[var(--color-bg-secondary)] rounded-lg">
            <p className="text-sm font-medium text-[var(--color-text-primary)] mb-2">Preview:</p>
            <div className="border border-[var(--color-border)] rounded-lg overflow-hidden">
              <iframe
                src={embedUrl}
                width="100%"
                height="400"
                style={{ border: 'none' }}
                title={`${title} Preview`}
                loading="lazy"
              />
            </div>
          </div>

          <p className="mt-3 text-xs text-[var(--color-text-muted)]">
            By embedding, you agree to our{' '}
            <a href="/terms" className="text-primary-500 hover:underline">Terms of Service</a>.
            Attribution is appreciated but not required.
          </p>
        </div>
      )}
    </div>
  )
}

