'use client'

import { useState, useCallback, useMemo } from 'react'
import type { CalculatorSpec, CalculatorInput, CalculatorOutput, CalculatorResult } from '@/types'
import { executeFormula } from '@/lib/formulas'
import { ShareButtons } from '@/components/calculator/ShareButtons'
import { EmbedCode } from '@/components/calculator/EmbedCode'
import { trackCalculatorUsage } from '@/components/analytics/Analytics'

interface CalculatorRendererProps {
  spec: CalculatorSpec
}

export function CalculatorRenderer({ spec }: CalculatorRendererProps) {
  // Initialize inputs with default values
  const initialInputs = useMemo(() => {
    const values: Record<string, string | number> = {}
    spec.inputs.forEach((input) => {
      values[input.id] = input.defaultValue ?? ''
    })
    return values
  }, [spec.inputs])

  const [inputs, setInputs] = useState<Record<string, string | number>>(initialInputs)
  const [result, setResult] = useState<CalculatorResult | null>(null)
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [isCalculating, setIsCalculating] = useState(false)

  // Handle input change
  const handleInputChange = useCallback((id: string, value: string | number) => {
    setInputs((prev) => ({ ...prev, [id]: value }))
    // Clear error for this field
    setErrors((prev) => {
      const next = { ...prev }
      delete next[id]
      return next
    })
  }, [])

  // Validate inputs
  const validateInputs = useCallback((): boolean => {
    const newErrors: Record<string, string> = {}
    let isValid = true

    spec.inputs.forEach((input) => {
      const value = inputs[input.id]
      
      // Check required
      if (input.validation?.required && (value === '' || value === undefined)) {
        newErrors[input.id] = input.validation.customMessage || 'This field is required'
        isValid = false
        return
      }

      // Check numeric validations
      if (input.type === 'number' || input.type === 'currency' || input.type === 'percentage') {
        const numValue = Number(value)
        if (value !== '' && isNaN(numValue)) {
          newErrors[input.id] = 'Please enter a valid number'
          isValid = false
          return
        }
        if (input.validation?.min !== undefined && numValue < input.validation.min) {
          newErrors[input.id] = `Minimum value is ${input.validation.min}`
          isValid = false
          return
        }
        if (input.validation?.max !== undefined && numValue > input.validation.max) {
          newErrors[input.id] = `Maximum value is ${input.validation.max}`
          isValid = false
          return
        }
      }
    })

    setErrors(newErrors)
    return isValid
  }, [inputs, spec.inputs])

  // Calculate result
  const handleCalculate = useCallback(() => {
    if (!validateInputs()) return

    setIsCalculating(true)
    
    // Small delay for UX feedback
    setTimeout(() => {
      const calcResult = executeFormula(spec.formulaId, inputs)
      setResult(calcResult)
      setIsCalculating(false)
      
      // Track usage
      trackCalculatorUsage(spec.slug, 'calculate')
    }, 100)
  }, [inputs, spec.formulaId, spec.slug, validateInputs])

  // Reset calculator
  const handleReset = useCallback(() => {
    setInputs(initialInputs)
    setResult(null)
    setErrors({})
  }, [initialInputs])

  // Check if an input should be shown based on conditional logic
  const shouldShowInput = (input: CalculatorInput): boolean => {
    if (!input.showWhen) return true
    const dependentValue = inputs[input.showWhen.inputId]
    return dependentValue === input.showWhen.value
  }

  // Render input field based on type
  const renderInput = (input: CalculatorInput) => {
    if (!shouldShowInput(input)) return null

    const value = inputs[input.id]
    const error = errors[input.id]
    const isRequired = input.validation?.required

    const baseInputClasses = `input ${error ? 'input-error' : ''} ${
      input.unitPosition === 'prefix' ? 'input-with-prefix' : ''
    } ${input.unitPosition === 'suffix' ? 'input-with-suffix' : ''}`

    switch (input.type) {
      case 'select':
        return (
          <div key={input.id} className="mb-4">
            <label htmlFor={input.id} className={`label ${isRequired ? 'label-required' : ''}`}>
              {input.label}
            </label>
            <select
              id={input.id}
              value={value}
              onChange={(e) => handleInputChange(input.id, e.target.value)}
              className="select"
              aria-describedby={input.helpText ? `${input.id}-help` : undefined}
            >
              {input.options?.map((opt) => (
                <option key={opt.value} value={opt.value}>
                  {opt.label}
                </option>
              ))}
            </select>
            {input.helpText && (
              <p id={`${input.id}-help`} className="mt-1 text-sm text-[var(--color-text-muted)]">
                {input.helpText}
              </p>
            )}
          </div>
        )

      case 'radio':
        return (
          <div key={input.id} className="mb-4">
            <label className={`label ${isRequired ? 'label-required' : ''}`}>
              {input.label}
            </label>
            <div className="flex flex-wrap gap-3 mt-2">
              {input.options?.map((opt) => (
                <label
                  key={opt.value}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg border cursor-pointer transition-colors ${
                    value === opt.value
                      ? 'border-primary-500 bg-primary-50 dark:bg-primary-950 text-primary-700 dark:text-primary-300'
                      : 'border-[var(--color-border)] hover:border-[var(--color-text-muted)]'
                  }`}
                >
                  <input
                    type="radio"
                    name={input.id}
                    value={opt.value}
                    checked={value === opt.value}
                    onChange={(e) => handleInputChange(input.id, e.target.value)}
                    className="sr-only"
                  />
                  <span className="text-sm font-medium">{opt.label}</span>
                </label>
              ))}
            </div>
            {input.helpText && (
              <p className="mt-1 text-sm text-[var(--color-text-muted)]">{input.helpText}</p>
            )}
          </div>
        )

      case 'date':
        return (
          <div key={input.id} className="mb-4">
            <label htmlFor={input.id} className={`label ${isRequired ? 'label-required' : ''}`}>
              {input.label}
            </label>
            <input
              type="date"
              id={input.id}
              value={value as string}
              onChange={(e) => handleInputChange(input.id, e.target.value)}
              className={baseInputClasses}
              aria-invalid={!!error}
              aria-describedby={error ? `${input.id}-error` : input.helpText ? `${input.id}-help` : undefined}
            />
            {error && (
              <p id={`${input.id}-error`} className="mt-1 text-sm text-red-500" role="alert">
                {error}
              </p>
            )}
            {input.helpText && !error && (
              <p id={`${input.id}-help`} className="mt-1 text-sm text-[var(--color-text-muted)]">
                {input.helpText}
              </p>
            )}
          </div>
        )

      case 'text':
        return (
          <div key={input.id} className="mb-4">
            <label htmlFor={input.id} className={`label ${isRequired ? 'label-required' : ''}`}>
              {input.label}
            </label>
            <input
              type="text"
              id={input.id}
              value={value as string}
              onChange={(e) => handleInputChange(input.id, e.target.value)}
              placeholder={input.placeholder}
              className={baseInputClasses}
              aria-invalid={!!error}
            />
            {error && (
              <p className="mt-1 text-sm text-red-500" role="alert">{error}</p>
            )}
            {input.helpText && !error && (
              <p className="mt-1 text-sm text-[var(--color-text-muted)]">{input.helpText}</p>
            )}
          </div>
        )

      default:
        // number, currency, percentage
        return (
          <div key={input.id} className="mb-4">
            <label htmlFor={input.id} className={`label ${isRequired ? 'label-required' : ''}`}>
              {input.label}
            </label>
            <div className="input-group">
              {input.unit && input.unitPosition === 'prefix' && (
                <span className="input-prefix">{input.unit}</span>
              )}
              <input
                type="number"
                id={input.id}
                value={value}
                onChange={(e) => handleInputChange(input.id, e.target.value)}
                placeholder={input.placeholder}
                className={baseInputClasses}
                step={input.validation?.step || 'any'}
                min={input.validation?.min}
                max={input.validation?.max}
                aria-invalid={!!error}
                aria-describedby={error ? `${input.id}-error` : input.helpText ? `${input.id}-help` : undefined}
              />
              {input.unit && input.unitPosition === 'suffix' && (
                <span className="input-suffix">{input.unit}</span>
              )}
            </div>
            {error && (
              <p id={`${input.id}-error`} className="mt-1 text-sm text-red-500" role="alert">
                {error}
              </p>
            )}
            {input.helpText && !error && (
              <p id={`${input.id}-help`} className="mt-1 text-sm text-[var(--color-text-muted)]">
                {input.helpText}
              </p>
            )}
          </div>
        )
    }
  }

  // Render output field
  const renderOutput = (output: CalculatorOutput) => {
    if (!result?.success || result.outputs[output.id] === null) return null

    const value = result.outputs[output.id]
    let displayValue: string

    switch (output.format) {
      case 'currency':
        displayValue = `$${Number(value).toLocaleString('en-US', {
          minimumFractionDigits: output.precision ?? 2,
          maximumFractionDigits: output.precision ?? 2,
        })}`
        break
      case 'percentage':
        displayValue = `${Number(value).toFixed(output.precision ?? 1)}%`
        break
      case 'number':
        displayValue = Number(value).toLocaleString('en-US', {
          minimumFractionDigits: 0,
          maximumFractionDigits: output.precision ?? 2,
        })
        if (output.unit) {
          displayValue = output.unitPosition === 'prefix' 
            ? `${output.unit}${displayValue}`
            : `${displayValue} ${output.unit}`
        }
        break
      default:
        displayValue = String(value)
    }

    if (output.highlight) {
      return (
        <div key={output.id} className="result-box mb-4">
          <p className="result-label">{output.label}</p>
          <p className="result-value">{displayValue}</p>
          {output.helpText && (
            <p className="mt-2 text-sm text-primary-600 dark:text-primary-400">{output.helpText}</p>
          )}
        </div>
      )
    }

    return (
      <div key={output.id} className="flex justify-between items-center py-3 border-b border-[var(--color-border)] last:border-0">
        <span className="text-[var(--color-text-secondary)]">{output.label}</span>
        <span className="font-medium text-[var(--color-text-primary)]">{displayValue}</span>
      </div>
    )
  }

  // Group inputs by group property
  const groupedInputs = useMemo(() => {
    const groups: Record<string, CalculatorInput[]> = { default: [] }
    spec.inputs.forEach((input) => {
      const group = input.group || 'default'
      if (!groups[group]) groups[group] = []
      groups[group].push(input)
    })
    return groups
  }, [spec.inputs])

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      {/* Input Section */}
      <div className="card">
        <h2 className="text-lg font-semibold mb-6 text-[var(--color-text-primary)]">
          Enter Values
        </h2>
        
        <form
          onSubmit={(e) => {
            e.preventDefault()
            handleCalculate()
          }}
        >
          {Object.entries(groupedInputs).map(([group, groupInputs]) => (
            <div key={group}>
              {group !== 'default' && (
                <h3 className="text-sm font-medium text-[var(--color-text-muted)] uppercase tracking-wider mt-6 mb-3">
                  {group}
                </h3>
              )}
              {groupInputs.map(renderInput)}
            </div>
          ))}

          <div className="flex gap-3 mt-6">
            <button type="submit" className="btn-primary flex-1" disabled={isCalculating}>
              {isCalculating ? (
                <>
                  <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                  </svg>
                  Calculating...
                </>
              ) : (
                'Calculate'
              )}
            </button>
            <button type="button" onClick={handleReset} className="btn-secondary">
              Reset
            </button>
          </div>
        </form>
      </div>

      {/* Results Section */}
      <div className="space-y-6">
        {/* Results Card */}
        <div className="card">
          <h2 className="text-lg font-semibold mb-6 text-[var(--color-text-primary)]">
            Results
          </h2>

          {!result && (
            <div className="text-center py-8 text-[var(--color-text-muted)]">
              <svg className="w-12 h-12 mx-auto mb-3 opacity-50" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
              </svg>
              <p>Enter values and click Calculate to see results</p>
            </div>
          )}

          {result && !result.success && (
            <div className="bg-red-50 dark:bg-red-950 border border-red-200 dark:border-red-800 rounded-lg p-4">
              <p className="text-red-700 dark:text-red-300">{result.error}</p>
            </div>
          )}

          {result?.success && (
            <div className="animate-fade-in">
              {spec.outputs.filter(o => o.highlight).map(renderOutput)}
              
              {spec.outputs.filter(o => !o.highlight).length > 0 && (
                <div className="mt-4 pt-4">
                  {spec.outputs.filter(o => !o.highlight).map(renderOutput)}
                </div>
              )}

              {result.breakdown && (
                <div className="mt-4 pt-4 border-t border-[var(--color-border)]">
                  <p className="text-sm font-medium text-[var(--color-text-muted)] mb-2">Breakdown</p>
                  {result.breakdown.map((item, idx) => (
                    <div key={idx} className="flex justify-between text-sm py-1">
                      <span className="text-[var(--color-text-secondary)]">{item.label}</span>
                      <span>{item.value}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Actions */}
        {result?.success && (
          <div className="card">
            <h3 className="text-sm font-medium text-[var(--color-text-muted)] uppercase tracking-wider mb-4">
              Actions
            </h3>
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => window.print()}
                className="btn-secondary text-sm"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z" />
                </svg>
                Print
              </button>
              <ShareButtons 
                title={spec.title}
                slug={spec.slug}
                result={result}
              />
            </div>
          </div>
        )}

        {/* Embed Code */}
        <EmbedCode slug={spec.slug} title={spec.title} />
      </div>
    </div>
  )
}

