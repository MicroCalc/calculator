'use client'

import { useState, useEffect, useRef, useCallback } from 'react'
import Link from 'next/link'
import Fuse from 'fuse.js'
import { getAllCalculators } from '@/lib/calculators'
import { CATEGORIES, CATEGORY_COLORS } from '@/lib/constants'
import type { CalculatorSpec } from '@/types'

interface SearchModalProps {
  isOpen: boolean
  onClose: () => void
}

export function SearchModal({ isOpen, onClose }: SearchModalProps) {
  const [query, setQuery] = useState('')
  const [results, setResults] = useState<CalculatorSpec[]>([])
  const [selectedIndex, setSelectedIndex] = useState(0)
  const inputRef = useRef<HTMLInputElement>(null)
  const resultsRef = useRef<HTMLDivElement>(null)
  const [fuse, setFuse] = useState<Fuse<CalculatorSpec> | null>(null)

  // Initialize Fuse.js search
  useEffect(() => {
    const calculators = getAllCalculators()
    const fuseInstance = new Fuse(calculators, {
      keys: [
        { name: 'title', weight: 2 },
        { name: 'shortTitle', weight: 1.5 },
        { name: 'description', weight: 1 },
        { name: 'seo.keywords', weight: 0.8 },
        { name: 'category', weight: 0.5 },
      ],
      threshold: 0.3,
      includeScore: true,
      minMatchCharLength: 2,
    })
    setFuse(fuseInstance)
  }, [])

  // Focus input when modal opens
  useEffect(() => {
    if (isOpen && inputRef.current) {
      inputRef.current.focus()
    }
    if (!isOpen) {
      setQuery('')
      setResults([])
      setSelectedIndex(0)
    }
  }, [isOpen])

  // Perform search
  useEffect(() => {
    if (!fuse || !query.trim()) {
      setResults([])
      return
    }

    const searchResults = fuse.search(query).slice(0, 8)
    setResults(searchResults.map(r => r.item))
    setSelectedIndex(0)
  }, [query, fuse])

  // Keyboard navigation
  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    switch (e.key) {
      case 'ArrowDown':
        e.preventDefault()
        setSelectedIndex(prev => Math.min(prev + 1, results.length - 1))
        break
      case 'ArrowUp':
        e.preventDefault()
        setSelectedIndex(prev => Math.max(prev - 1, 0))
        break
      case 'Enter':
        e.preventDefault()
        if (results[selectedIndex]) {
          window.location.href = `/calculators/${results[selectedIndex].slug}`
          onClose()
        }
        break
      case 'Escape':
        onClose()
        break
    }
  }, [results, selectedIndex, onClose])

  // Scroll selected item into view
  useEffect(() => {
    if (resultsRef.current && results.length > 0) {
      const selectedElement = resultsRef.current.children[selectedIndex] as HTMLElement
      if (selectedElement) {
        selectedElement.scrollIntoView({ block: 'nearest' })
      }
    }
  }, [selectedIndex, results.length])

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50" role="dialog" aria-modal="true" aria-label="Search calculators">
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/50 backdrop-blur-sm animate-fade-in"
        onClick={onClose}
        aria-hidden="true"
      />

      {/* Modal */}
      <div className="fixed inset-x-4 top-[10%] md:inset-x-auto md:left-1/2 md:-translate-x-1/2 md:w-full md:max-w-2xl animate-slide-down">
        <div className="bg-[var(--color-bg-card)] rounded-2xl shadow-2xl border border-[var(--color-border)] overflow-hidden">
          {/* Search input */}
          <div className="flex items-center gap-3 px-4 py-4 border-b border-[var(--color-border)]">
            <svg
              className="w-5 h-5 text-[var(--color-text-muted)]"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
              />
            </svg>
            <input
              ref={inputRef}
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Search calculators..."
              className="flex-1 bg-transparent text-[var(--color-text-primary)] placeholder-[var(--color-text-muted)] outline-none text-lg"
              autoComplete="off"
              spellCheck={false}
            />
            <button
              onClick={onClose}
              className="p-1.5 text-[var(--color-text-muted)] hover:text-[var(--color-text-primary)] hover:bg-[var(--color-bg-tertiary)] rounded-lg transition-colors"
              aria-label="Close search"
            >
              <kbd className="text-xs font-mono px-1.5 py-0.5 bg-[var(--color-bg-tertiary)] rounded">
                ESC
              </kbd>
            </button>
          </div>

          {/* Results */}
          <div ref={resultsRef} className="max-h-[60vh] overflow-y-auto">
            {query && results.length === 0 && (
              <div className="px-4 py-12 text-center text-[var(--color-text-muted)]">
                <p className="text-lg mb-2">No calculators found</p>
                <p className="text-sm">Try a different search term</p>
              </div>
            )}

            {results.map((calculator, index) => {
              const categoryColors = CATEGORY_COLORS[calculator.category]
              const category = CATEGORIES.find(c => c.id === calculator.category)
              
              return (
                <Link
                  key={calculator.slug}
                  href={`/calculators/${calculator.slug}`}
                  onClick={onClose}
                  className={`flex items-start gap-4 px-4 py-3 transition-colors ${
                    index === selectedIndex
                      ? 'bg-primary-50 dark:bg-primary-950'
                      : 'hover:bg-[var(--color-bg-tertiary)]'
                  }`}
                >
                  <span className="text-2xl mt-0.5" aria-hidden="true">
                    {calculator.icon || category?.icon}
                  </span>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <h4 className="font-medium text-[var(--color-text-primary)] truncate">
                        {calculator.title}
                      </h4>
                      <span className={`badge ${categoryColors.bg} ${categoryColors.text} text-xs`}>
                        {category?.name}
                      </span>
                    </div>
                    <p className="text-sm text-[var(--color-text-secondary)] truncate mt-0.5">
                      {calculator.description}
                    </p>
                  </div>
                  <svg
                    className="w-5 h-5 text-[var(--color-text-muted)] mt-1 flex-shrink-0"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </Link>
              )
            })}

            {/* Quick links when no query */}
            {!query && (
              <div className="px-4 py-4">
                <p className="text-xs font-medium text-[var(--color-text-muted)] uppercase tracking-wider mb-3">
                  Browse by Category
                </p>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                  {CATEGORIES.map((category) => (
                    <Link
                      key={category.id}
                      href={`/category/${category.slug}`}
                      onClick={onClose}
                      className="flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-[var(--color-bg-tertiary)] transition-colors"
                    >
                      <span aria-hidden="true">{category.icon}</span>
                      <span className="text-sm text-[var(--color-text-secondary)]">
                        {category.name}
                      </span>
                    </Link>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="px-4 py-3 border-t border-[var(--color-border)] bg-[var(--color-bg-tertiary)]">
            <div className="flex items-center justify-between text-xs text-[var(--color-text-muted)]">
              <div className="flex items-center gap-4">
                <span className="flex items-center gap-1">
                  <kbd className="px-1.5 py-0.5 bg-[var(--color-bg-card)] rounded border border-[var(--color-border)]">↑</kbd>
                  <kbd className="px-1.5 py-0.5 bg-[var(--color-bg-card)] rounded border border-[var(--color-border)]">↓</kbd>
                  <span className="ml-1">Navigate</span>
                </span>
                <span className="flex items-center gap-1">
                  <kbd className="px-1.5 py-0.5 bg-[var(--color-bg-card)] rounded border border-[var(--color-border)]">↵</kbd>
                  <span className="ml-1">Select</span>
                </span>
              </div>
              <Link
                href="/calculators"
                onClick={onClose}
                className="hover:text-primary-500 transition-colors"
              >
                View all calculators →
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

