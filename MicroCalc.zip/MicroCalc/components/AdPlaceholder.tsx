'use client';

import React from 'react';
import { cn } from '@/lib/utils';
import { ADSENSE_CONFIG } from '@/lib/constants';

interface AdPlaceholderProps {
  slot: 'header' | 'footer' | 'sidebar' | 'inArticle';
  className?: string;
}

/**
 * AdSense Placeholder Component
 * 
 * This component renders a placeholder for AdSense ads.
 * In production, replace the placeholder content with actual AdSense code.
 * 
 * To enable ads:
 * 1. Add your AdSense client ID to NEXT_PUBLIC_ADSENSE_CLIENT_ID env variable
 * 2. Add your ad slot IDs to lib/constants.ts ADSENSE_CONFIG
 * 3. Uncomment the AdSense script in app/layout.tsx
 * 4. Replace the placeholder div with actual AdSense code
 */
export default function AdPlaceholder({ slot, className }: AdPlaceholderProps) {
  const slotConfig = {
    header: {
      height: 'h-24',
      label: 'Header Banner Ad',
      slotId: ADSENSE_CONFIG.slots.headerBanner,
    },
    footer: {
      height: 'h-24',
      label: 'Footer Banner Ad',
      slotId: ADSENSE_CONFIG.slots.footerBanner,
    },
    sidebar: {
      height: 'h-64',
      label: 'Sidebar Ad',
      slotId: ADSENSE_CONFIG.slots.sidebarAd,
    },
    inArticle: {
      height: 'h-32',
      label: 'In-Article Ad',
      slotId: ADSENSE_CONFIG.slots.inArticle,
    },
  };

  const config = slotConfig[slot];
  const hasAdSense = Boolean(ADSENSE_CONFIG.clientId);

  // In production with AdSense configured, render actual ad
  if (hasAdSense && process.env.NODE_ENV === 'production') {
    return (
      <div className={cn('overflow-hidden', className)}>
        <ins
          className="adsbygoogle"
          style={{ display: 'block' }}
          data-ad-client={ADSENSE_CONFIG.clientId}
          data-ad-slot={config.slotId}
          data-ad-format="auto"
          data-full-width-responsive="true"
        />
        <script
          dangerouslySetInnerHTML={{
            __html: '(adsbygoogle = window.adsbygoogle || []).push({});',
          }}
        />
      </div>
    );
  }

  // Placeholder for development
  return (
    <div
      className={cn(
        'flex items-center justify-center rounded-lg',
        'bg-surface-100 dark:bg-surface-800',
        'border-2 border-dashed border-surface-300 dark:border-surface-600',
        'text-surface-400 dark:text-surface-500 text-sm',
        config.height,
        className
      )}
    >
      <div className="text-center">
        <svg className="w-8 h-8 mx-auto mb-2 opacity-50" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
        </svg>
        <span>{config.label}</span>
        <p className="text-xs opacity-75 mt-1">Add AdSense ID to enable</p>
      </div>
    </div>
  );
}

/**
 * Instructions for enabling Google AdSense:
 * 
 * 1. Sign up for Google AdSense at https://www.google.com/adsense
 * 2. Add your site and get approved
 * 3. Get your client ID (ca-pub-XXXXXXXXXXXXXXXX) and ad unit slot IDs
 * 4. Set environment variables:
 *    NEXT_PUBLIC_ADSENSE_CLIENT_ID=ca-pub-XXXXXXXXXXXXXXXX
 * 5. Update ADSENSE_CONFIG.slots in lib/constants.ts with your slot IDs
 * 6. Add the AdSense script to your layout:
 *    <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-XXXXXXXXXXXXXXXX" crossOrigin="anonymous" />
 * 7. Deploy and verify ads are showing
 * 
 * For testing, use AdSense test mode by adding data-adtest="on" to ins tags.
 */

