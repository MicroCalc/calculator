/**
 * MicroCalc Calculator Types
 * Defines the structure for calculator specifications and configurations
 */

// Calculator categories
export type CalculatorCategory = 
  | 'finance'
  | 'health'
  | 'math'
  | 'datetime'
  | 'converters'
  | 'other';

// Input field types
export type InputType = 
  | 'number'
  | 'currency'
  | 'percentage'
  | 'date'
  | 'select'
  | 'radio'
  | 'text'
  | 'range';

// Validation rules for inputs
export interface InputValidation {
  required?: boolean;
  min?: number;
  max?: number;
  step?: number;
  pattern?: string;
  minLength?: number;
  maxLength?: number;
  customMessage?: string;
}

// Select/Radio option
export interface InputOption {
  value: string | number;
  label: string;
}

// Calculator input field specification
export interface CalculatorInput {
  id: string;
  label: string;
  type: InputType;
  placeholder?: string;
  defaultValue?: string | number;
  helpText?: string;
  validation?: InputValidation;
  options?: InputOption[];  // For select/radio types
  unit?: string;            // Display unit (e.g., "$", "%", "kg")
  unitPosition?: 'prefix' | 'suffix';
  group?: string;           // For grouping related inputs
  dependsOn?: string;       // ID of input this depends on
  showWhen?: {              // Conditional display
    inputId: string;
    value: string | number | boolean;
  };
}

// Output result field
export interface CalculatorOutput {
  id: string;
  label: string;
  format: 'number' | 'currency' | 'percentage' | 'date' | 'text' | 'duration';
  precision?: number;
  unit?: string;
  unitPosition?: 'prefix' | 'suffix';
  highlight?: boolean;      // Primary result to highlight
  helpText?: string;
}

// FAQ item for JSON-LD
export interface FAQItem {
  question: string;
  answer: string;
}

// Related calculator link
export interface RelatedCalculator {
  slug: string;
  title: string;
  description?: string;
}

// Example calculation for the page
export interface CalculatorExample {
  title: string;
  description: string;
  inputs: Record<string, string | number>;
  expectedOutputs: Record<string, string | number>;
}

// Formula/algorithm specification
export interface FormulaSpec {
  description: string;
  formula?: string;         // Mathematical formula (LaTeX or plain text)
  pseudocode?: string;      // Algorithm description
  variables?: {
    name: string;
    description: string;
  }[];
}

// SEO metadata
export interface SEOMetadata {
  title: string;
  description: string;
  keywords?: string[];
  canonicalPath?: string;
  ogImage?: string;
  noIndex?: boolean;
}

// Complete calculator specification
export interface CalculatorSpec {
  // Basic info
  slug: string;
  title: string;
  shortTitle?: string;      // Shorter title for navigation/cards
  category: CalculatorCategory;
  description: string;      // Short description (for cards/lists)
  introduction: string;     // Full intro paragraph (100-200 words)
  
  // Icon/visual
  icon?: string;            // Icon name or emoji
  color?: string;           // Category color override
  
  // Inputs and outputs
  inputs: CalculatorInput[];
  outputs: CalculatorOutput[];
  
  // Formula/calculation
  formula: FormulaSpec;
  formulaId: string;        // ID to match with formula function in lib/formulas.ts
  
  // Content
  howToUse?: string;        // Instructions section
  examples: CalculatorExample[];
  faq: FAQItem[];
  relatedCalculators: RelatedCalculator[];
  
  // SEO
  seo: SEOMetadata;
  
  // Status
  isImplemented: boolean;   // Whether the formula logic is complete
  lastUpdated?: string;     // ISO date string
  version?: string;
}

// Calculator result after computation
export interface CalculatorResult {
  success: boolean;
  outputs: Record<string, number | string | null>;
  error?: string;
  warnings?: string[];
  breakdown?: {             // Optional detailed breakdown
    label: string;
    value: string | number;
  }[];
}

// Category metadata
export interface CategoryInfo {
  id: CalculatorCategory;
  name: string;
  description: string;
  icon: string;
  color: string;
  slug: string;
}

// Search result item
export interface SearchResult {
  slug: string;
  title: string;
  description: string;
  category: CalculatorCategory;
  score: number;
}

// Embed widget configuration
export interface EmbedConfig {
  slug: string;
  width?: number | string;
  height?: number | string;
  theme?: 'light' | 'dark' | 'auto';
  showBranding?: boolean;
  primaryColor?: string;
}

// API response types
export interface CalculatorPreview {
  slug: string;
  title: string;
  description: string;
  category: CalculatorCategory;
  inputs: Pick<CalculatorInput, 'id' | 'label' | 'type'>[];
  url: string;
  embedUrl: string;
}

// Localization
export interface LocaleStrings {
  common: {
    calculate: string;
    reset: string;
    result: string;
    share: string;
    print: string;
    embed: string;
    copy: string;
    copied: string;
    error: string;
    required: string;
    invalid: string;
    search: string;
    searchPlaceholder: string;
    noResults: string;
    loading: string;
    darkMode: string;
    lightMode: string;
    categories: string;
    allCalculators: string;
    relatedCalculators: string;
    faq: string;
    formula: string;
    howToUse: string;
    example: string;
  };
  categories: Record<CalculatorCategory, string>;
  calculator: Record<string, {
    title: string;
    description: string;
    introduction: string;
    inputs: Record<string, string>;
    outputs: Record<string, string>;
    faq: FAQItem[];
  }>;
}
