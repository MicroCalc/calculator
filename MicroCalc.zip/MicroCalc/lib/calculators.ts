import type { CalculatorSpec, CalculatorCategory } from '@/types'

// Import all calculator specs
import mortgageSpec from '@/data/calculators/mortgage.json'
import loanSpec from '@/data/calculators/loan.json'
import autoLoanSpec from '@/data/calculators/auto-loan.json'
import interestSpec from '@/data/calculators/interest.json'
import paymentSpec from '@/data/calculators/payment.json'
import retirementSpec from '@/data/calculators/retirement.json'
import amortizationSpec from '@/data/calculators/amortization.json'
import investmentSpec from '@/data/calculators/investment.json'
import inflationSpec from '@/data/calculators/inflation.json'
import financeSpec from '@/data/calculators/finance.json'
import incomeTaxSpec from '@/data/calculators/income-tax.json'
import compoundInterestSpec from '@/data/calculators/compound-interest.json'
import salarySpec from '@/data/calculators/salary.json'
import interestRateSpec from '@/data/calculators/interest-rate.json'
import salesTaxSpec from '@/data/calculators/sales-tax.json'
import bmiSpec from '@/data/calculators/bmi.json'
import calorieSpec from '@/data/calculators/calorie.json'
import bodyFatSpec from '@/data/calculators/body-fat.json'
import bmrSpec from '@/data/calculators/bmr.json'
import idealWeightSpec from '@/data/calculators/ideal-weight.json'
import paceSpec from '@/data/calculators/pace.json'
import pregnancySpec from '@/data/calculators/pregnancy.json'
import conceptionSpec from '@/data/calculators/conception.json'
import dueDateSpec from '@/data/calculators/due-date.json'
import scientificSpec from '@/data/calculators/scientific.json'
import fractionSpec from '@/data/calculators/fraction.json'
import percentageSpec from '@/data/calculators/percentage.json'
import randomNumberSpec from '@/data/calculators/random-number.json'
import triangleSpec from '@/data/calculators/triangle.json'
import standardDeviationSpec from '@/data/calculators/standard-deviation.json'
import ageSpec from '@/data/calculators/age.json'
import dateSpec from '@/data/calculators/date.json'
import timeSpec from '@/data/calculators/time.json'
import hoursSpec from '@/data/calculators/hours.json'
import gpaSpec from '@/data/calculators/gpa.json'
import gradeSpec from '@/data/calculators/grade.json'
import concreteSpec from '@/data/calculators/concrete.json'
import subnetSpec from '@/data/calculators/subnet.json'
import passwordSpec from '@/data/calculators/password.json'
import conversionSpec from '@/data/calculators/conversion.json'
import fuelCostSpec from '@/data/calculators/fuel-cost.json'

// All calculator specs
const CALCULATOR_SPECS: CalculatorSpec[] = [
  mortgageSpec as CalculatorSpec,
  loanSpec as CalculatorSpec,
  autoLoanSpec as CalculatorSpec,
  interestSpec as CalculatorSpec,
  paymentSpec as CalculatorSpec,
  retirementSpec as CalculatorSpec,
  amortizationSpec as CalculatorSpec,
  investmentSpec as CalculatorSpec,
  inflationSpec as CalculatorSpec,
  financeSpec as CalculatorSpec,
  incomeTaxSpec as CalculatorSpec,
  compoundInterestSpec as CalculatorSpec,
  salarySpec as CalculatorSpec,
  interestRateSpec as CalculatorSpec,
  salesTaxSpec as CalculatorSpec,
  bmiSpec as CalculatorSpec,
  calorieSpec as CalculatorSpec,
  bodyFatSpec as CalculatorSpec,
  bmrSpec as CalculatorSpec,
  idealWeightSpec as CalculatorSpec,
  paceSpec as CalculatorSpec,
  pregnancySpec as CalculatorSpec,
  conceptionSpec as CalculatorSpec,
  dueDateSpec as CalculatorSpec,
  scientificSpec as CalculatorSpec,
  fractionSpec as CalculatorSpec,
  percentageSpec as CalculatorSpec,
  randomNumberSpec as CalculatorSpec,
  triangleSpec as CalculatorSpec,
  standardDeviationSpec as CalculatorSpec,
  ageSpec as CalculatorSpec,
  dateSpec as CalculatorSpec,
  timeSpec as CalculatorSpec,
  hoursSpec as CalculatorSpec,
  gpaSpec as CalculatorSpec,
  gradeSpec as CalculatorSpec,
  concreteSpec as CalculatorSpec,
  subnetSpec as CalculatorSpec,
  passwordSpec as CalculatorSpec,
  conversionSpec as CalculatorSpec,
  fuelCostSpec as CalculatorSpec,
]

/**
 * Get all calculator specifications
 */
export function getAllCalculators(): CalculatorSpec[] {
  return CALCULATOR_SPECS
}

/**
 * Get calculator by slug
 */
export function getCalculatorBySlug(slug: string): CalculatorSpec | undefined {
  return CALCULATOR_SPECS.find(calc => calc.slug === slug)
}

/**
 * Get calculators by category
 */
export function getCalculatorsByCategory(category: CalculatorCategory): CalculatorSpec[] {
  return CALCULATOR_SPECS.filter(calc => calc.category === category)
}

/**
 * Get all implemented calculators (with full logic)
 */
export function getImplementedCalculators(): CalculatorSpec[] {
  return CALCULATOR_SPECS.filter(calc => calc.isImplemented)
}

/**
 * Get all calculator slugs (for static generation)
 */
export function getAllCalculatorSlugs(): string[] {
  return CALCULATOR_SPECS.map(calc => calc.slug)
}

/**
 * Get related calculators based on category and exclude current
 */
export function getRelatedCalculators(currentSlug: string, limit: number = 4): CalculatorSpec[] {
  const current = getCalculatorBySlug(currentSlug)
  if (!current) return []

  // First, get calculators from the same category
  const sameCategory = CALCULATOR_SPECS.filter(
    calc => calc.category === current.category && calc.slug !== currentSlug
  )

  // If we have enough from the same category, return them
  if (sameCategory.length >= limit) {
    return sameCategory.slice(0, limit)
  }

  // Otherwise, add popular calculators from other categories
  const others = CALCULATOR_SPECS.filter(
    calc => calc.category !== current.category && calc.slug !== currentSlug && calc.isImplemented
  )

  return [...sameCategory, ...others].slice(0, limit)
}

/**
 * Get featured calculators for homepage
 */
export function getFeaturedCalculators(): CalculatorSpec[] {
  const featuredSlugs = [
    'mortgage',
    'bmi',
    'compound-interest',
    'age',
    'scientific',
    'salary',
  ]
  
  return featuredSlugs
    .map(slug => getCalculatorBySlug(slug))
    .filter((calc): calc is CalculatorSpec => calc !== undefined)
}

/**
 * Get calculator count by category
 */
export function getCalculatorCountByCategory(): Record<CalculatorCategory, number> {
  const counts: Record<CalculatorCategory, number> = {
    finance: 0,
    health: 0,
    math: 0,
    datetime: 0,
    converters: 0,
    other: 0,
  }

  CALCULATOR_SPECS.forEach(calc => {
    counts[calc.category]++
  })

  return counts
}

/**
 * Search calculators by query
 */
export function searchCalculators(query: string): CalculatorSpec[] {
  const normalizedQuery = query.toLowerCase().trim()
  
  if (!normalizedQuery) return []

  return CALCULATOR_SPECS.filter(calc => {
    const searchableText = [
      calc.title,
      calc.shortTitle,
      calc.description,
      calc.seo.keywords?.join(' '),
    ]
      .filter(Boolean)
      .join(' ')
      .toLowerCase()

    return searchableText.includes(normalizedQuery)
  })
}
