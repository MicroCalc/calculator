import type { CategoryInfo, CalculatorCategory } from '@/types'

export const SITE_NAME = 'MicroCalc'
export const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://microcalc.app'
export const SITE_DESCRIPTION = 'Free online calculators for finance, health, math, and more. Fast, accurate, and easy to use.'

// Calculator categories with metadata
export const CATEGORIES: CategoryInfo[] = [
  {
    id: 'finance',
    name: 'Finance',
    description: 'Calculate mortgages, loans, investments, interest rates, and more financial metrics.',
    icon: '💰',
    color: '#10b981',
    slug: 'finance',
  },
  {
    id: 'health',
    name: 'Health',
    description: 'Track your BMI, calculate calories, body fat percentage, and other health metrics.',
    icon: '❤️',
    color: '#ec4899',
    slug: 'health',
  },
  {
    id: 'math',
    name: 'Math',
    description: 'Scientific calculator, fractions, percentages, statistics, and mathematical operations.',
    icon: '📐',
    color: '#6366f1',
    slug: 'math',
  },
  {
    id: 'datetime',
    name: 'Date & Time',
    description: 'Calculate ages, dates, time differences, and schedule-related computations.',
    icon: '📅',
    color: '#06b6d4',
    slug: 'date-time',
  },
  {
    id: 'converters',
    name: 'Converters',
    description: 'Convert units, currencies, measurements, and other values between different formats.',
    icon: '🔄',
    color: '#8b5cf6',
    slug: 'converters',
  },
  {
    id: 'other',
    name: 'Other',
    description: 'GPA calculators, password generators, subnet calculators, and more specialized tools.',
    icon: '🛠️',
    color: '#f97316',
    slug: 'other',
  },
]

// Get category by ID
export function getCategoryById(id: CalculatorCategory): CategoryInfo | undefined {
  return CATEGORIES.find(cat => cat.id === id)
}

// Get category by slug
export function getCategoryBySlug(slug: string): CategoryInfo | undefined {
  return CATEGORIES.find(cat => cat.slug === slug)
}

// Category colors for Tailwind classes
export const CATEGORY_COLORS: Record<CalculatorCategory, { bg: string; text: string; border: string }> = {
  finance: {
    bg: 'bg-emerald-100 dark:bg-emerald-900/30',
    text: 'text-emerald-700 dark:text-emerald-300',
    border: 'border-emerald-200 dark:border-emerald-800',
  },
  health: {
    bg: 'bg-pink-100 dark:bg-pink-900/30',
    text: 'text-pink-700 dark:text-pink-300',
    border: 'border-pink-200 dark:border-pink-800',
  },
  math: {
    bg: 'bg-indigo-100 dark:bg-indigo-900/30',
    text: 'text-indigo-700 dark:text-indigo-300',
    border: 'border-indigo-200 dark:border-indigo-800',
  },
  datetime: {
    bg: 'bg-cyan-100 dark:bg-cyan-900/30',
    text: 'text-cyan-700 dark:text-cyan-300',
    border: 'border-cyan-200 dark:border-cyan-800',
  },
  converters: {
    bg: 'bg-violet-100 dark:bg-violet-900/30',
    text: 'text-violet-700 dark:text-violet-300',
    border: 'border-violet-200 dark:border-violet-800',
  },
  other: {
    bg: 'bg-orange-100 dark:bg-orange-900/30',
    text: 'text-orange-700 dark:text-orange-300',
    border: 'border-orange-200 dark:border-orange-800',
  },
}

// Input validation patterns
export const VALIDATION_PATTERNS = {
  email: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
  phone: /^[\d\s\-\+\(\)]+$/,
  number: /^-?\d*\.?\d+$/,
  positiveNumber: /^\d*\.?\d+$/,
  integer: /^-?\d+$/,
  positiveInteger: /^\d+$/,
  percentage: /^(100(\.0+)?|[0-9]{1,2}(\.\d+)?)$/,
  currency: /^\d+(\.\d{0,2})?$/,
}

// Number formatting options
export const NUMBER_FORMATS = {
  currency: {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  },
  percent: {
    style: 'percent',
    minimumFractionDigits: 1,
    maximumFractionDigits: 2,
  },
  decimal: {
    style: 'decimal',
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  },
  integer: {
    style: 'decimal',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  },
}

// Default meta values
export const DEFAULT_META = {
  title: `${SITE_NAME} - Free Online Calculators`,
  description: SITE_DESCRIPTION,
  keywords: ['calculator', 'online calculator', 'free calculator'],
}

// Social share base URLs
export const SHARE_URLS = {
  twitter: 'https://twitter.com/intent/tweet',
  facebook: 'https://www.facebook.com/sharer/sharer.php',
  whatsapp: 'https://wa.me/',
  linkedin: 'https://www.linkedin.com/sharing/share-offsite/',
  email: 'mailto:',
}

// AdSense placeholder dimensions
export const AD_SIZES = {
  banner: { width: 728, height: 90 },
  rectangle: { width: 300, height: 250 },
  leaderboard: { width: 970, height: 90 },
  skyscraper: { width: 160, height: 600 },
  mobile: { width: 320, height: 100 },
}
