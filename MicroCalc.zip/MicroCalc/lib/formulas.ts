/**
 * MicroCalc Formula Library
 * Contains all calculation logic for implemented calculators
 * 
 * Each formula function receives an object with input values
 * and returns a CalculatorResult with computed outputs
 */

import type { CalculatorResult } from '@/types'

// ============================================
// MORTGAGE CALCULATOR
// ============================================
export function calculateMortgage(inputs: Record<string, number | string>): CalculatorResult {
  try {
    const homePrice = Number(inputs.homePrice) || 0
    const downPayment = Number(inputs.downPayment) || 0
    const interestRate = Number(inputs.interestRate) || 0
    const loanTerm = Number(inputs.loanTerm) || 30
    const propertyTax = Number(inputs.propertyTax) || 0
    const homeInsurance = Number(inputs.homeInsurance) || 0

    const loanAmount = homePrice - downPayment
    const monthlyRate = interestRate / 100 / 12
    const numberOfPayments = loanTerm * 12

    let monthlyPayment: number
    
    if (monthlyRate === 0) {
      monthlyPayment = loanAmount / numberOfPayments
    } else {
      monthlyPayment = loanAmount * 
        (monthlyRate * Math.pow(1 + monthlyRate, numberOfPayments)) / 
        (Math.pow(1 + monthlyRate, numberOfPayments) - 1)
    }

    const monthlyPropertyTax = propertyTax / 12
    const monthlyInsurance = homeInsurance / 12
    const totalMonthlyPayment = monthlyPayment + monthlyPropertyTax + monthlyInsurance
    const totalPayment = monthlyPayment * numberOfPayments
    const totalInterest = totalPayment - loanAmount

    return {
      success: true,
      outputs: {
        monthlyPayment: Math.round(monthlyPayment * 100) / 100,
        totalMonthlyPayment: Math.round(totalMonthlyPayment * 100) / 100,
        totalPayment: Math.round(totalPayment * 100) / 100,
        totalInterest: Math.round(totalInterest * 100) / 100,
        loanAmount: loanAmount,
      },
      breakdown: [
        { label: 'Principal & Interest', value: `$${monthlyPayment.toFixed(2)}` },
        { label: 'Property Tax', value: `$${monthlyPropertyTax.toFixed(2)}` },
        { label: 'Home Insurance', value: `$${monthlyInsurance.toFixed(2)}` },
      ],
    }
  } catch (error) {
    return { success: false, outputs: {}, error: 'Invalid input values' }
  }
}

// ============================================
// LOAN CALCULATOR
// ============================================
export function calculateLoan(inputs: Record<string, number | string>): CalculatorResult {
  try {
    const loanAmount = Number(inputs.loanAmount) || 0
    const interestRate = Number(inputs.interestRate) || 0
    const loanTerm = Number(inputs.loanTerm) || 60

    const monthlyRate = interestRate / 100 / 12
    const numberOfPayments = loanTerm

    let monthlyPayment: number

    if (monthlyRate === 0) {
      monthlyPayment = loanAmount / numberOfPayments
    } else {
      monthlyPayment = loanAmount * 
        (monthlyRate * Math.pow(1 + monthlyRate, numberOfPayments)) / 
        (Math.pow(1 + monthlyRate, numberOfPayments) - 1)
    }

    const totalPayment = monthlyPayment * numberOfPayments
    const totalInterest = totalPayment - loanAmount

    return {
      success: true,
      outputs: {
        monthlyPayment: Math.round(monthlyPayment * 100) / 100,
        totalPayment: Math.round(totalPayment * 100) / 100,
        totalInterest: Math.round(totalInterest * 100) / 100,
      },
    }
  } catch (error) {
    return { success: false, outputs: {}, error: 'Invalid input values' }
  }
}

// ============================================
// AUTO LOAN CALCULATOR
// ============================================
export function calculateAutoLoan(inputs: Record<string, number | string>): CalculatorResult {
  try {
    const vehiclePrice = Number(inputs.vehiclePrice) || 0
    const downPayment = Number(inputs.downPayment) || 0
    const tradeInValue = Number(inputs.tradeInValue) || 0
    const interestRate = Number(inputs.interestRate) || 0
    const loanTerm = Number(inputs.loanTerm) || 60
    const salesTaxRate = Number(inputs.salesTaxRate) || 0

    const salesTax = vehiclePrice * (salesTaxRate / 100)
    const loanAmount = vehiclePrice + salesTax - downPayment - tradeInValue

    const monthlyRate = interestRate / 100 / 12
    const numberOfPayments = loanTerm

    let monthlyPayment: number

    if (monthlyRate === 0) {
      monthlyPayment = loanAmount / numberOfPayments
    } else {
      monthlyPayment = loanAmount * 
        (monthlyRate * Math.pow(1 + monthlyRate, numberOfPayments)) / 
        (Math.pow(1 + monthlyRate, numberOfPayments) - 1)
    }

    const totalPayment = monthlyPayment * numberOfPayments
    const totalInterest = totalPayment - loanAmount
    const totalCost = totalPayment + downPayment + tradeInValue

    return {
      success: true,
      outputs: {
        monthlyPayment: Math.round(monthlyPayment * 100) / 100,
        loanAmount: Math.round(loanAmount * 100) / 100,
        totalPayment: Math.round(totalPayment * 100) / 100,
        totalInterest: Math.round(totalInterest * 100) / 100,
        totalCost: Math.round(totalCost * 100) / 100,
      },
    }
  } catch (error) {
    return { success: false, outputs: {}, error: 'Invalid input values' }
  }
}

// ============================================
// BMI CALCULATOR
// ============================================
export function calculateBMI(inputs: Record<string, number | string>): CalculatorResult {
  try {
    const unit = String(inputs.unit) || 'imperial'
    const weight = Number(inputs.weight) || 0

    let heightInMeters: number

    if (unit === 'imperial') {
      const heightFeet = Number(inputs.heightFeet) || 0
      const heightInches = Number(inputs.heightInches) || 0
      const totalInches = heightFeet * 12 + heightInches
      heightInMeters = totalInches * 0.0254
    } else {
      const heightCm = Number(inputs.heightCm) || 0
      heightInMeters = heightCm / 100
    }

    // Convert weight to kg if imperial
    const weightKg = unit === 'imperial' ? weight * 0.453592 : weight

    const bmi = weightKg / (heightInMeters * heightInMeters)

    // Determine BMI category
    let category: string
    if (bmi < 18.5) category = 'Underweight'
    else if (bmi < 25) category = 'Normal weight'
    else if (bmi < 30) category = 'Overweight'
    else if (bmi < 35) category = 'Obese (Class I)'
    else if (bmi < 40) category = 'Obese (Class II)'
    else category = 'Obese (Class III)'

    // Calculate healthy weight range (BMI 18.5-24.9)
    const minHealthyWeight = 18.5 * (heightInMeters * heightInMeters)
    const maxHealthyWeight = 24.9 * (heightInMeters * heightInMeters)
    const idealWeight = 22 * (heightInMeters * heightInMeters)

    // Convert back to user's unit
    const weightUnit = unit === 'imperial' ? 'lb' : 'kg'
    const minDisplay = unit === 'imperial' ? minHealthyWeight / 0.453592 : minHealthyWeight
    const maxDisplay = unit === 'imperial' ? maxHealthyWeight / 0.453592 : maxHealthyWeight
    const idealDisplay = unit === 'imperial' ? idealWeight / 0.453592 : idealWeight

    return {
      success: true,
      outputs: {
        bmi: Math.round(bmi * 10) / 10,
        category: category,
        healthyWeightRange: `${Math.round(minDisplay)} - ${Math.round(maxDisplay)} ${weightUnit}`,
        idealWeight: `${Math.round(idealDisplay)} ${weightUnit}`,
      },
    }
  } catch (error) {
    return { success: false, outputs: {}, error: 'Invalid input values' }
  }
}

// ============================================
// AGE CALCULATOR
// ============================================
export function calculateAge(inputs: Record<string, number | string>): CalculatorResult {
  try {
    const birthDateStr = String(inputs.birthDate)
    const targetDateStr = inputs.targetDate ? String(inputs.targetDate) : new Date().toISOString().split('T')[0]

    const birthDate = new Date(birthDateStr)
    const targetDate = new Date(targetDateStr)

    if (isNaN(birthDate.getTime())) {
      return { success: false, outputs: {}, error: 'Invalid birth date' }
    }

    // Calculate age
    let years = targetDate.getFullYear() - birthDate.getFullYear()
    let months = targetDate.getMonth() - birthDate.getMonth()
    let days = targetDate.getDate() - birthDate.getDate()

    if (days < 0) {
      months--
      const prevMonth = new Date(targetDate.getFullYear(), targetDate.getMonth(), 0)
      days += prevMonth.getDate()
    }

    if (months < 0) {
      years--
      months += 12
    }

    // Total calculations
    const diffMs = targetDate.getTime() - birthDate.getTime()
    const totalDays = Math.floor(diffMs / (1000 * 60 * 60 * 24))
    const totalWeeks = Math.floor(totalDays / 7)
    const totalMonths = years * 12 + months
    const totalHours = totalDays * 24

    // Next birthday
    let nextBirthday = new Date(targetDate.getFullYear(), birthDate.getMonth(), birthDate.getDate())
    if (nextBirthday <= targetDate) {
      nextBirthday = new Date(targetDate.getFullYear() + 1, birthDate.getMonth(), birthDate.getDate())
    }
    const daysUntilBirthday = Math.ceil((nextBirthday.getTime() - targetDate.getTime()) / (1000 * 60 * 60 * 24))

    return {
      success: true,
      outputs: {
        ageYears: years,
        ageDetailed: `${years} years, ${months} months, ${days} days`,
        totalMonths: totalMonths,
        totalWeeks: totalWeeks,
        totalDays: totalDays,
        totalHours: totalHours,
        nextBirthday: nextBirthday.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }),
        daysUntilBirthday: daysUntilBirthday,
      },
    }
  } catch (error) {
    return { success: false, outputs: {}, error: 'Invalid input values' }
  }
}

// ============================================
// DATE CALCULATOR
// ============================================
export function calculateDate(inputs: Record<string, number | string>): CalculatorResult {
  try {
    const mode = String(inputs.mode) || 'difference'
    const startDateStr = String(inputs.startDate)
    const startDate = new Date(startDateStr)

    if (isNaN(startDate.getTime())) {
      return { success: false, outputs: {}, error: 'Invalid start date' }
    }

    if (mode === 'difference') {
      const endDateStr = String(inputs.endDate)
      const endDate = new Date(endDateStr)
      const includeEndDate = String(inputs.includeEndDate) === 'yes'

      if (isNaN(endDate.getTime())) {
        return { success: false, outputs: {}, error: 'Invalid end date' }
      }

      let diffMs = endDate.getTime() - startDate.getTime()
      let totalDays = Math.floor(diffMs / (1000 * 60 * 60 * 24))
      if (includeEndDate) totalDays++

      // Count weekdays and weekends
      let weekdays = 0
      let weekends = 0
      const current = new Date(startDate)
      const end = includeEndDate ? new Date(endDate.getTime() + 86400000) : endDate

      while (current < end) {
        const day = current.getDay()
        if (day === 0 || day === 6) weekends++
        else weekdays++
        current.setDate(current.getDate() + 1)
      }

      // Calculate years, months, days breakdown
      let years = endDate.getFullYear() - startDate.getFullYear()
      let months = endDate.getMonth() - startDate.getMonth()
      let days = endDate.getDate() - startDate.getDate()

      if (days < 0) {
        months--
        days += new Date(endDate.getFullYear(), endDate.getMonth(), 0).getDate()
      }
      if (months < 0) {
        years--
        months += 12
      }

      return {
        success: true,
        outputs: {
          resultDate: endDate.toISOString().split('T')[0],
          totalDays: totalDays,
          weeks: Math.floor(totalDays / 7),
          weekdays: weekdays,
          weekends: weekends,
          breakdown: `${years} years, ${months} months, ${days} days`,
        },
      }
    } else {
      // Add/subtract days mode
      const daysToAdd = Number(inputs.daysToAdd) || 0
      const resultDate = new Date(startDate)
      resultDate.setDate(resultDate.getDate() + daysToAdd)

      return {
        success: true,
        outputs: {
          resultDate: resultDate.toISOString().split('T')[0],
          totalDays: Math.abs(daysToAdd),
          weeks: Math.floor(Math.abs(daysToAdd) / 7),
          weekdays: null,
          weekends: null,
          breakdown: resultDate.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }),
        },
      }
    }
  } catch (error) {
    return { success: false, outputs: {}, error: 'Invalid input values' }
  }
}

// ============================================
// SALARY CALCULATOR (BANGLADESH)
// ============================================
export function calculateSalaryBangladesh(inputs: Record<string, number | string>): CalculatorResult {
  try {
    const grossSalary = Number(inputs.grossSalary) || 0
    const basicPercentage = Number(inputs.basicPercentage) || 60
    const pfContribution = Number(inputs.pfContribution) || 10
    const taxArea = String(inputs.taxArea) || 'dhaka'
    const gender = String(inputs.gender) || 'male'
    const hasDisability = String(inputs.hasDisability) === 'yes'

    const basicSalary = grossSalary * (basicPercentage / 100)
    const yearlyGross = grossSalary * 12
    const pfDeduction = basicSalary * (pfContribution / 100)

    // Tax exemption limits (FY 2023-24)
    let exemptionLimit: number
    if (hasDisability) {
      exemptionLimit = 475000
    } else if (gender === 'female') {
      exemptionLimit = 400000
    } else {
      exemptionLimit = 350000
    }

    // Calculate taxable income
    const taxableIncome = Math.max(0, yearlyGross - exemptionLimit)

    // Bangladesh tax slabs (simplified)
    let yearlyTax = 0
    let remaining = taxableIncome

    const slabs = [
      { limit: 100000, rate: 0.05 },
      { limit: 400000, rate: 0.10 },
      { limit: 500000, rate: 0.15 },
      { limit: 500000, rate: 0.20 },
      { limit: Infinity, rate: 0.25 },
    ]

    for (const slab of slabs) {
      if (remaining <= 0) break
      const taxableInSlab = Math.min(remaining, slab.limit)
      yearlyTax += taxableInSlab * slab.rate
      remaining -= taxableInSlab
    }

    // Minimum tax based on area
    const minTax = taxArea === 'dhaka' ? 5000 : taxArea === 'other_city' ? 4000 : 3000
    if (taxableIncome > 0 && yearlyTax < minTax) {
      yearlyTax = minTax
    }

    const monthlyTax = yearlyTax / 12
    const netSalary = grossSalary - monthlyTax - pfDeduction
    const effectiveTaxRate = (yearlyTax / yearlyGross) * 100

    return {
      success: true,
      outputs: {
        netSalary: Math.round(netSalary),
        basicSalary: Math.round(basicSalary),
        monthlyTax: Math.round(monthlyTax),
        yearlyTax: Math.round(yearlyTax),
        pfDeduction: Math.round(pfDeduction),
        yearlyGross: yearlyGross,
        effectiveTaxRate: Math.round(effectiveTaxRate * 100) / 100,
      },
    }
  } catch (error) {
    return { success: false, outputs: {}, error: 'Invalid input values' }
  }
}

// ============================================
// FUEL COST CALCULATOR
// ============================================
export function calculateFuelCost(inputs: Record<string, number | string>): CalculatorResult {
  try {
    const unit = String(inputs.unit) || 'imperial'
    const distance = Number(inputs.distance) || 0
    const fuelEfficiency = Number(inputs.fuelEfficiency) || 30
    const fuelPrice = Number(inputs.fuelPrice) || 3.50
    const roundTrip = String(inputs.roundTrip) === 'yes'
    const passengers = Number(inputs.passengers) || 1

    const totalDistance = roundTrip ? distance * 2 : distance

    let fuelNeeded: number
    if (unit === 'imperial') {
      // MPG
      fuelNeeded = totalDistance / fuelEfficiency
    } else {
      // L/100km
      fuelNeeded = totalDistance * (fuelEfficiency / 100)
    }

    const totalCost = fuelNeeded * fuelPrice
    const costPerPerson = totalCost / passengers
    const costPerUnit = totalCost / totalDistance

    const distanceUnit = unit === 'imperial' ? 'mile' : 'km'
    const fuelUnit = unit === 'imperial' ? 'gallons' : 'liters'

    return {
      success: true,
      outputs: {
        totalCost: Math.round(totalCost * 100) / 100,
        fuelNeeded: Math.round(fuelNeeded * 100) / 100,
        costPerPerson: Math.round(costPerPerson * 100) / 100,
        costPerMile: Math.round(costPerUnit * 1000) / 1000,
        totalDistance: totalDistance,
      },
      breakdown: [
        { label: 'Distance', value: `${totalDistance} ${distanceUnit}s` },
        { label: 'Fuel Needed', value: `${fuelNeeded.toFixed(2)} ${fuelUnit}` },
        { label: 'Fuel Price', value: `$${fuelPrice.toFixed(2)}/${fuelUnit.slice(0, -1)}` },
      ],
    }
  } catch (error) {
    return { success: false, outputs: {}, error: 'Invalid input values' }
  }
}

// ============================================
// COMPOUND INTEREST CALCULATOR
// ============================================
export function calculateCompoundInterest(inputs: Record<string, number | string>): CalculatorResult {
  try {
    const principal = Number(inputs.principal) || 0
    const monthlyContribution = Number(inputs.monthlyContribution) || 0
    const interestRate = Number(inputs.interestRate) || 0
    const years = Number(inputs.years) || 0
    const compoundFrequency = String(inputs.compoundFrequency) || 'monthly'

    // Determine compounding periods per year
    const frequencyMap: Record<string, number> = {
      annually: 1,
      semiannually: 2,
      quarterly: 4,
      monthly: 12,
      daily: 365,
    }
    const n = frequencyMap[compoundFrequency] || 12
    const r = interestRate / 100

    // Future value of initial principal
    const fvPrincipal = principal * Math.pow(1 + r / n, n * years)

    // Future value of regular contributions (annuity)
    // Adjust for contribution frequency (monthly contributions with different compounding)
    const contributionPeriods = years * 12
    const monthlyRate = r / 12
    let fvContributions = 0

    if (monthlyContribution > 0) {
      if (monthlyRate > 0) {
        fvContributions = monthlyContribution * 
          ((Math.pow(1 + monthlyRate, contributionPeriods) - 1) / monthlyRate)
      } else {
        fvContributions = monthlyContribution * contributionPeriods
      }
    }

    const futureValue = fvPrincipal + fvContributions
    const totalContributions = principal + (monthlyContribution * contributionPeriods)
    const totalInterest = futureValue - totalContributions

    // Effective annual rate (APY)
    const effectiveRate = (Math.pow(1 + r / n, n) - 1) * 100

    return {
      success: true,
      outputs: {
        futureValue: Math.round(futureValue * 100) / 100,
        totalContributions: totalContributions,
        totalInterest: Math.round(totalInterest * 100) / 100,
        effectiveRate: Math.round(effectiveRate * 100) / 100,
      },
    }
  } catch (error) {
    return { success: false, outputs: {}, error: 'Invalid input values' }
  }
}

// ============================================
// SCIENTIFIC CALCULATOR
// ============================================
export function calculateScientific(inputs: Record<string, number | string>): CalculatorResult {
  try {
    const expression = String(inputs.expression) || ''
    const angleMode = String(inputs.angleMode) || 'degrees'

    if (!expression.trim()) {
      return { success: false, outputs: {}, error: 'Please enter an expression' }
    }

    // Create a safe evaluation context
    let processedExpr = expression
      .toLowerCase()
      .replace(/\s+/g, '')
      // Replace constants
      .replace(/\bpi\b/g, String(Math.PI))
      .replace(/\be\b/g, String(Math.E))
      // Replace functions
      .replace(/sqrt\(/g, 'Math.sqrt(')
      .replace(/abs\(/g, 'Math.abs(')
      .replace(/log\(/g, 'Math.log10(')
      .replace(/ln\(/g, 'Math.log(')
      .replace(/exp\(/g, 'Math.exp(')
      .replace(/floor\(/g, 'Math.floor(')
      .replace(/ceil\(/g, 'Math.ceil(')
      .replace(/round\(/g, 'Math.round(')
      // Handle exponentiation
      .replace(/\^/g, '**')

    // Handle trigonometric functions with angle conversion
    const trigFuncs = ['sin', 'cos', 'tan']
    const invTrigFuncs = ['asin', 'acos', 'atan']

    for (const func of trigFuncs) {
      const regex = new RegExp(`${func}\\(([^)]+)\\)`, 'g')
      if (angleMode === 'degrees') {
        processedExpr = processedExpr.replace(regex, `Math.${func}(($1)*Math.PI/180)`)
      } else {
        processedExpr = processedExpr.replace(regex, `Math.${func}($1)`)
      }
    }

    for (const func of invTrigFuncs) {
      const regex = new RegExp(`${func}\\(([^)]+)\\)`, 'g')
      if (angleMode === 'degrees') {
        processedExpr = processedExpr.replace(regex, `(Math.${func}($1)*180/Math.PI)`)
      } else {
        processedExpr = processedExpr.replace(regex, `Math.${func}($1)`)
      }
    }

    // Handle factorial
    processedExpr = processedExpr.replace(/(\d+)!/g, (_, num) => {
      let result = 1
      for (let i = 2; i <= parseInt(num); i++) result *= i
      return String(result)
    })

    // Validate expression - only allow safe characters
    if (!/^[0-9+\-*/().Math\s,a-z]+$/.test(processedExpr)) {
      return { success: false, outputs: {}, error: 'Invalid characters in expression' }
    }

    // Evaluate using Function constructor (safer than eval)
    const result = new Function(`"use strict"; return (${processedExpr})`)()

    if (typeof result !== 'number' || isNaN(result) || !isFinite(result)) {
      return { success: false, outputs: {}, error: 'Invalid result' }
    }

    return {
      success: true,
      outputs: {
        result: Math.round(result * 1e10) / 1e10, // 10 decimal precision
      },
    }
  } catch (error) {
    return { success: false, outputs: {}, error: 'Invalid expression' }
  }
}

// ============================================
// FORMULA REGISTRY
// Maps formulaId to formula functions
// ============================================
export const FORMULA_REGISTRY: Record<string, (inputs: Record<string, number | string>) => CalculatorResult> = {
  mortgage: calculateMortgage,
  loan: calculateLoan,
  autoLoan: calculateAutoLoan,
  bmi: calculateBMI,
  age: calculateAge,
  date: calculateDate,
  salaryBangladesh: calculateSalaryBangladesh,
  fuelCost: calculateFuelCost,
  compoundInterest: calculateCompoundInterest,
  scientific: calculateScientific,
}

/**
 * Execute a calculator formula by ID
 */
export function executeFormula(
  formulaId: string,
  inputs: Record<string, number | string>
): CalculatorResult {
  const formula = FORMULA_REGISTRY[formulaId]
  
  if (!formula) {
    return {
      success: false,
      outputs: {},
      error: `Calculator "${formulaId}" is not yet implemented. Coming soon!`,
    }
  }

  return formula(inputs)
}

/**
 * Check if a formula is implemented
 */
export function isFormulaImplemented(formulaId: string): boolean {
  return formulaId in FORMULA_REGISTRY
}

// ============================================
// PLACEHOLDER FUNCTIONS FOR UNIMPLEMENTED CALCULATORS
// TODO: Implement these functions
// ============================================

/*
 * Interest Calculator
 * Formula: Simple: I = P × r × t | Compound: A = P(1 + r/n)^(nt)
 * TODO: Implement simple and compound interest calculation
 */

/*
 * Payment Calculator
 * Formula: M = P × [r(1+r)^n] / [(1+r)^n - 1]
 * TODO: Implement loan payment calculation
 */

/*
 * Retirement Calculator
 * Formula: FV = PV(1+r)^n + PMT[((1+r)^n - 1)/r]
 * TODO: Implement retirement savings projection
 */

// ... Additional placeholder comments for other calculators
