import { Metadata } from 'next'
import Link from 'next/link'

export const metadata: Metadata = {
  title: 'About MicroCalc',
  description: 'Learn about MicroCalc - a free online calculator hub with 40+ calculators for finance, health, math, and more.',
  alternates: {
    canonical: '/about',
  },
}

export default function AboutPage() {
  return (
    <main className="container-app py-8">
      <div className="max-w-3xl mx-auto">
        <header className="text-center mb-12">
          <span className="text-5xl block mb-4">🧮</span>
          <h1 className="text-3xl md:text-4xl font-bold text-[var(--color-text-primary)] mb-4">
            About MicroCalc
          </h1>
          <p className="text-lg text-[var(--color-text-secondary)]">
            Free, fast, and accurate online calculators for everyone
          </p>
        </header>

        <div className="prose-calc space-y-8">
          <section>
            <h2>Our Mission</h2>
            <p>
              MicroCalc was created with a simple mission: to provide free, reliable, and easy-to-use 
              calculators for everyday needs. Whether you&apos;re planning a mortgage, tracking your health 
              metrics, solving math problems, or calculating dates, we&apos;re here to help.
            </p>
          </section>

          <section>
            <h2>What We Offer</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 not-prose">
              {[
                { icon: '💰', title: 'Finance', desc: 'Mortgages, loans, investments, interest calculations' },
                { icon: '❤️', title: 'Health', desc: 'BMI, calories, body fat, ideal weight' },
                { icon: '📐', title: 'Math', desc: 'Scientific calculator, fractions, statistics' },
                { icon: '📅', title: 'Date & Time', desc: 'Age, date differences, time calculations' },
                { icon: '🔄', title: 'Converters', desc: 'Unit conversions for length, weight, temperature' },
                { icon: '🛠️', title: 'Other', desc: 'GPA, passwords, subnet, and more' },
              ].map((item) => (
                <div key={item.title} className="card p-4">
                  <span className="text-2xl block mb-2">{item.icon}</span>
                  <h3 className="font-semibold text-[var(--color-text-primary)] mb-1">{item.title}</h3>
                  <p className="text-sm text-[var(--color-text-secondary)]">{item.desc}</p>
                </div>
              ))}
            </div>
          </section>

          <section>
            <h2>Our Principles</h2>
            <ul>
              <li><strong>Free Forever</strong> - All calculators are and will remain free to use</li>
              <li><strong>Privacy First</strong> - Calculations happen in your browser; we don&apos;t store your data</li>
              <li><strong>Accuracy</strong> - We use industry-standard formulas and regularly verify results</li>
              <li><strong>Accessibility</strong> - Designed to work for everyone, on any device</li>
              <li><strong>Transparency</strong> - We show our formulas and explain our calculations</li>
            </ul>
          </section>

          <section>
            <h2>For Developers & Partners</h2>
            <p>
              Want to embed our calculators on your website? We offer free embeddable widgets 
              that you can add to your blog, website, or application. Visit our{' '}
              <Link href="/tools/embed-directory" className="text-primary-500 hover:underline">
                embed directory
              </Link>{' '}
              to get started.
            </p>
            <p>
              For partnership opportunities, custom integrations, or business inquiries, 
              please{' '}
              <Link href="/contact" className="text-primary-500 hover:underline">
                contact us
              </Link>.
            </p>
          </section>

          <section>
            <h2>Technology</h2>
            <p>
              MicroCalc is built with modern web technologies for speed and reliability:
            </p>
            <ul>
              <li>Next.js 14 with App Router for server-side rendering</li>
              <li>TypeScript for type safety</li>
              <li>Tailwind CSS for styling</li>
              <li>Hosted on Vercel for global performance</li>
            </ul>
          </section>

          <section>
            <h2>Disclaimer</h2>
            <p>
              While we strive for accuracy, our calculators are for informational purposes only. 
              Always consult qualified professionals for important financial, medical, or legal decisions. 
              Read our full{' '}
              <Link href="/disclaimer" className="text-primary-500 hover:underline">
                disclaimer
              </Link>.
            </p>
          </section>
        </div>

        <div className="mt-12 text-center">
          <Link href="/calculators" className="btn-primary">
            Explore Our Calculators
          </Link>
        </div>
      </div>
    </main>
  )
}

