import { Metadata } from 'next'
import Link from 'next/link'
import { getAllCalculators } from '@/lib/calculators'
import { getCategoryById } from '@/lib/constants'

export const metadata: Metadata = {
  title: 'Search Calculators',
  description: 'Search through our collection of 40+ free online calculators.',
  alternates: {
    canonical: '/search',
  },
}

export default function SearchPage({
  searchParams,
}: {
  searchParams: { q?: string }
}) {
  const query = searchParams.q?.toLowerCase() || ''
  const allCalculators = getAllCalculators()
  
  const results = query
    ? allCalculators.filter((calc) => {
        const searchText = [
          calc.title,
          calc.shortTitle,
          calc.description,
          calc.seo.keywords?.join(' '),
        ]
          .filter(Boolean)
          .join(' ')
          .toLowerCase()
        return searchText.includes(query)
      })
    : []

  return (
    <main className="container-app py-8">
      <div className="max-w-3xl mx-auto">
        <header className="mb-8">
          <h1 className="text-3xl font-bold text-[var(--color-text-primary)] mb-4">
            Search Calculators
          </h1>
          
          {/* Search form */}
          <form action="/search" method="GET">
            <div className="relative">
              <input
                type="text"
                name="q"
                defaultValue={query}
                placeholder="Search calculators..."
                className="input pl-12"
                autoFocus
              />
              <svg
                className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[var(--color-text-muted)]"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                />
              </svg>
            </div>
          </form>
        </header>

        {/* Results */}
        {query && (
          <div>
            <p className="text-[var(--color-text-secondary)] mb-6">
              {results.length === 0
                ? `No results found for "${query}"`
                : `Found ${results.length} calculator${results.length === 1 ? '' : 's'} for "${query}"`}
            </p>

            <div className="space-y-4">
              {results.map((calc) => {
                const category = getCategoryById(calc.category)
                return (
                  <Link
                    key={calc.slug}
                    href={`/calculators/${calc.slug}`}
                    className="card card-hover block"
                  >
                    <div className="flex items-start gap-4">
                      <span className="text-2xl">{calc.icon || category?.icon}</span>
                      <div>
                        <h2 className="font-semibold text-[var(--color-text-primary)]">
                          {calc.title}
                        </h2>
                        <p className="text-sm text-[var(--color-text-secondary)] mt-1">
                          {calc.description}
                        </p>
                        <span className={`badge badge-${calc.category} mt-2`}>
                          {category?.name}
                        </span>
                      </div>
                    </div>
                  </Link>
                )
              })}
            </div>
          </div>
        )}

        {/* No query - show browse options */}
        {!query && (
          <div className="text-center py-8">
            <p className="text-[var(--color-text-secondary)] mb-4">
              Enter a search term above or browse by category
            </p>
            <Link href="/calculators" className="btn-primary">
              Browse All Calculators
            </Link>
          </div>
        )}
      </div>
    </main>
  )
}
