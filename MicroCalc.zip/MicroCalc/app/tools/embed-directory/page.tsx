import { Metadata } from 'next'
import Link from 'next/link'
import { getAllCalculators } from '@/lib/calculators'
import { getCategoryById } from '@/lib/constants'

export const metadata: Metadata = {
  title: 'Embed Calculators - Free Widget Directory',
  description: 'Embed our free calculators on your website or blog. Get iframe code for any calculator with customizable options.',
  alternates: {
    canonical: '/tools/embed-directory',
  },
}

export default function EmbedDirectoryPage() {
  const allCalculators = getAllCalculators()
  const implementedCalculators = allCalculators.filter(c => c.isImplemented)
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || 'https://microcalc.app'

  const exampleCode = `<iframe 
  src="${siteUrl}/embed/mortgage" 
  width="100%" 
  height="500" 
  style="border: 1px solid #e5e7eb; border-radius: 8px;" 
  title="Mortgage Calculator"
  loading="lazy"
></iframe>`

  return (
    <main className="container-app py-8">
      {/* Header */}
      <header className="text-center mb-12">
        <span className="text-5xl mb-4 block">🔗</span>
        <h1 className="text-3xl md:text-4xl font-bold text-[var(--color-text-primary)] mb-4">
          Embed Calculators on Your Website
        </h1>
        <p className="text-lg text-[var(--color-text-secondary)] max-w-2xl mx-auto">
          Add our powerful calculators to your website, blog, or application for free. 
          Simple iframe integration with no signup required.
        </p>
      </header>

      {/* Benefits */}
      <section className="mb-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            {
              icon: '🎁',
              title: '100% Free',
              description: 'No costs, no ads, no restrictions. Use on any website.',
            },
            {
              icon: '⚡',
              title: 'Fast & Light',
              description: 'Optimized widgets that load quickly and don\'t slow your site.',
            },
            {
              icon: '🎨',
              title: 'Responsive',
              description: 'Works on all screen sizes. Adapts to your container width.',
            },
          ].map((benefit) => (
            <div key={benefit.title} className="card text-center">
              <span className="text-3xl mb-3 block">{benefit.icon}</span>
              <h3 className="font-semibold text-[var(--color-text-primary)] mb-2">
                {benefit.title}
              </h3>
              <p className="text-sm text-[var(--color-text-secondary)]">
                {benefit.description}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* How to Use */}
      <section className="mb-12">
        <h2 className="text-2xl font-bold text-[var(--color-text-primary)] mb-6">
          How to Embed
        </h2>
        <div className="card">
          <ol className="space-y-4">
            <li className="flex gap-4">
              <span className="flex-shrink-0 w-8 h-8 bg-primary-100 dark:bg-primary-900 text-primary-600 dark:text-primary-400 rounded-full flex items-center justify-center font-bold">
                1
              </span>
              <div>
                <h3 className="font-medium text-[var(--color-text-primary)]">Choose a Calculator</h3>
                <p className="text-sm text-[var(--color-text-secondary)]">
                  Select the calculator you want from the list below.
                </p>
              </div>
            </li>
            <li className="flex gap-4">
              <span className="flex-shrink-0 w-8 h-8 bg-primary-100 dark:bg-primary-900 text-primary-600 dark:text-primary-400 rounded-full flex items-center justify-center font-bold">
                2
              </span>
              <div>
                <h3 className="font-medium text-[var(--color-text-primary)]">Copy the Embed Code</h3>
                <p className="text-sm text-[var(--color-text-secondary)]">
                  Click on any calculator page and find the &quot;Embed This Calculator&quot; section.
                </p>
              </div>
            </li>
            <li className="flex gap-4">
              <span className="flex-shrink-0 w-8 h-8 bg-primary-100 dark:bg-primary-900 text-primary-600 dark:text-primary-400 rounded-full flex items-center justify-center font-bold">
                3
              </span>
              <div>
                <h3 className="font-medium text-[var(--color-text-primary)]">Paste in Your Site</h3>
                <p className="text-sm text-[var(--color-text-secondary)]">
                  Add the iframe code to your HTML where you want the calculator to appear.
                </p>
              </div>
            </li>
          </ol>

          <div className="mt-6">
            <h4 className="font-medium text-[var(--color-text-primary)] mb-2">Example Code:</h4>
            <pre className="bg-[var(--color-bg-tertiary)] rounded-lg p-4 text-sm overflow-x-auto font-mono text-[var(--color-text-secondary)]">
              {exampleCode}
            </pre>
          </div>
        </div>
      </section>

      {/* Available Calculators */}
      <section className="mb-12">
        <h2 className="text-2xl font-bold text-[var(--color-text-primary)] mb-6">
          Available Calculators ({implementedCalculators.length} Ready to Embed)
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {implementedCalculators.map((calc) => {
            const category = getCategoryById(calc.category)
            return (
              <Link
                key={calc.slug}
                href={`/calculators/${calc.slug}`}
                className="card card-hover"
              >
                <div className="flex items-center gap-3">
                  <span className="text-2xl">{calc.icon || category?.icon}</span>
                  <div>
                    <h3 className="font-medium text-[var(--color-text-primary)]">
                      {calc.title}
                    </h3>
                    <p className="text-xs text-[var(--color-text-muted)]">
                      {category?.name}
                    </p>
                  </div>
                </div>
              </Link>
            )
          })}
        </div>
        
        {/* Coming Soon */}
        <div className="mt-8 p-6 bg-[var(--color-bg-secondary)] rounded-xl">
          <h3 className="font-semibold text-[var(--color-text-primary)] mb-4">
            Coming Soon ({allCalculators.length - implementedCalculators.length} more calculators)
          </h3>
          <div className="flex flex-wrap gap-2">
            {allCalculators.filter(c => !c.isImplemented).map((calc) => (
              <span
                key={calc.slug}
                className="px-3 py-1 text-sm bg-[var(--color-bg-tertiary)] text-[var(--color-text-muted)] rounded-full"
              >
                {calc.shortTitle || calc.title}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* Partner Program */}
      <section className="card bg-gradient-to-r from-primary-50 to-primary-100 dark:from-primary-950 dark:to-primary-900 border-primary-200 dark:border-primary-800">
        <div className="flex flex-col md:flex-row items-center gap-6">
          <div className="flex-1">
            <h2 className="text-2xl font-bold text-[var(--color-text-primary)] mb-2">
              Partner Program
            </h2>
            <p className="text-[var(--color-text-secondary)] mb-4">
              Are you a financial blogger, real estate site, or content creator? 
              Join our partner program for custom integrations, priority support, 
              and co-branding opportunities.
            </p>
            <Link href="/contact" className="btn-primary">
              Contact Us
            </Link>
          </div>
          <span className="text-6xl">🤝</span>
        </div>
      </section>

      {/* Terms */}
      <section className="mt-12 text-center text-sm text-[var(--color-text-muted)]">
        <p>
          By embedding our calculators, you agree to our{' '}
          <Link href="/terms" className="text-primary-500 hover:underline">Terms of Service</Link>.
          {' '}Attribution is appreciated but not required.
        </p>
      </section>
    </main>
  )
}
