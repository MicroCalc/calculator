import type { Metadata, Viewport } from 'next'
import { Outfit, JetBrains_Mono } from 'next/font/google'
import './globals.css'
import { Header } from '@/components/layout/Header'
import { Footer } from '@/components/layout/Footer'
import { ThemeProvider } from '@/components/providers/ThemeProvider'
import { Analytics } from '@/components/analytics/Analytics'
import { JsonLdSoftwareApplication } from '@/components/seo/JsonLd'

// Custom fonts
const outfit = Outfit({
  subsets: ['latin'],
  variable: '--font-display',
  display: 'swap',
})

const jetbrainsMono = JetBrains_Mono({
  subsets: ['latin'],
  variable: '--font-geist-mono',
  display: 'swap',
})

// Site metadata
export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || 'https://microcalc.app'),
  title: {
    default: 'MicroCalc - Free Online Calculators for Finance, Health, Math & More',
    template: '%s | MicroCalc',
  },
  description: 'MicroCalc offers 40+ free online calculators for mortgages, loans, BMI, age, dates, conversions, and more. Fast, accurate, and easy to use calculators with no signup required.',
  keywords: [
    'calculator',
    'online calculator',
    'free calculator',
    'mortgage calculator',
    'loan calculator',
    'BMI calculator',
    'age calculator',
    'date calculator',
    'financial calculator',
    'health calculator',
    'math calculator',
    'conversion calculator',
  ],
  authors: [{ name: 'MicroCalc Team' }],
  creator: 'MicroCalc',
  publisher: 'MicroCalc',
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  openGraph: {
    type: 'website',
    locale: 'en_US',
    url: '/',
    siteName: 'MicroCalc',
    title: 'MicroCalc - Free Online Calculators',
    description: 'MicroCalc offers 40+ free online calculators for mortgages, loans, BMI, age, dates, conversions, and more.',
    images: [
      {
        url: '/og-image.png',
        width: 1200,
        height: 630,
        alt: 'MicroCalc - Online Calculator Hub',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'MicroCalc - Free Online Calculators',
    description: 'MicroCalc offers 40+ free online calculators for mortgages, loans, BMI, age, dates, conversions, and more.',
    images: ['/og-image.png'],
    creator: '@microcalc',
  },
  icons: {
    icon: [
      { url: '/favicon.ico' },
      { url: '/icon-16.png', sizes: '16x16', type: 'image/png' },
      { url: '/icon-32.png', sizes: '32x32', type: 'image/png' },
    ],
    apple: [
      { url: '/apple-touch-icon.png', sizes: '180x180', type: 'image/png' },
    ],
  },
  manifest: '/manifest.json',
  alternates: {
    canonical: '/',
  },
  verification: {
    google: process.env.NEXT_PUBLIC_GOOGLE_SITE_VERIFICATION,
    other: {
      'msvalidate.01': process.env.NEXT_PUBLIC_BING_SITE_VERIFICATION || '',
    },
  },
}

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 5,
  themeColor: [
    { media: '(prefers-color-scheme: light)', color: '#f59e0b' },
    { media: '(prefers-color-scheme: dark)', color: '#1e293b' },
  ],
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        {/* Preconnect to external resources */}
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        
        {/* JSON-LD for the site as a SoftwareApplication */}
        <JsonLdSoftwareApplication />
      </head>
      <body className={`${outfit.variable} ${jetbrainsMono.variable} font-sans antialiased`}>
        <ThemeProvider>
          <div className="flex min-h-screen flex-col">
            <Header />
            <main className="flex-1">
              {children}
            </main>
            <Footer />
          </div>
          <Analytics />
        </ThemeProvider>
      </body>
    </html>
  )
}
