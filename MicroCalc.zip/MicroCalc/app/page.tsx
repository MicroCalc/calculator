import Link from 'next/link'
import { CATEGORIES, getCategoryById } from '@/lib/constants'
import { getAllCalculators, getFeaturedCalculators, getCalculatorCountByCategory } from '@/lib/calculators'
import { ResponsiveAd } from '@/components/ads/AdPlaceholder'
import { JsonLdWebSite, JsonLdOrganization } from '@/components/seo/JsonLd'

export default function HomePage() {
  const featuredCalculators = getFeaturedCalculators()
  const calculatorCounts = getCalculatorCountByCategory()
  const totalCalculators = getAllCalculators().length

  return (
    <>
      <JsonLdWebSite />
      <JsonLdOrganization />

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-primary-50 via-white to-secondary-50 dark:from-secondary-900 dark:via-secondary-950 dark:to-secondary-900">
        {/* Background pattern */}
        <div className="absolute inset-0 bg-grid-pattern opacity-30 dark:opacity-10" />
        
        <div className="container-app relative py-16 md:py-24">
          <div className="max-w-3xl mx-auto text-center animate-fade-in">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-[var(--color-text-primary)] mb-6 font-display">
              Free Online{' '}
              <span className="text-gradient">Calculators</span>
            </h1>
            <p className="text-lg md:text-xl text-[var(--color-text-secondary)] mb-8">
              {totalCalculators}+ calculators for finance, health, math, and more. 
              Fast, accurate, and completely free. No signup required.
            </p>
            
            {/* Quick search */}
            <div className="relative max-w-xl mx-auto">
              <Link
                href="/calculators"
                className="flex items-center gap-3 px-5 py-4 bg-[var(--color-bg-card)] border border-[var(--color-border)] rounded-xl shadow-lg hover:shadow-xl hover:border-primary-300 transition-all"
              >
                <svg className="w-5 h-5 text-[var(--color-text-muted)]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
                <span className="text-[var(--color-text-muted)]">Search calculators...</span>
                <kbd className="ml-auto px-2 py-1 text-xs font-mono bg-[var(--color-bg-tertiary)] rounded border border-[var(--color-border)]">
                  ⌘K
                </kbd>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Ad Placeholder */}
      <section className="py-6 bg-[var(--color-bg-secondary)]">
        <div className="container-app">
          <ResponsiveAd />
        </div>
      </section>

      {/* Categories Section */}
      <section className="section bg-[var(--color-bg-primary)]">
        <div className="container-app">
          <div className="text-center mb-12">
            <h2 className="section-title">Calculator Categories</h2>
            <p className="section-subtitle">Browse our collection organized by category</p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {CATEGORIES.map((category, index) => (
              <Link
                key={category.id}
                href={`/category/${category.slug}`}
                className="card card-hover text-center p-6 animate-slide-up"
                style={{ animationDelay: `${index * 50}ms` }}
              >
                <span className="text-4xl mb-3 block">{category.icon}</span>
                <h3 className="font-semibold text-[var(--color-text-primary)] mb-1">
                  {category.name}
                </h3>
                <p className="text-sm text-[var(--color-text-muted)]">
                  {calculatorCounts[category.id]} calculators
                </p>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Calculators */}
      <section className="section bg-[var(--color-bg-secondary)]">
        <div className="container-app">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="section-title mb-0">Popular Calculators</h2>
              <p className="text-[var(--color-text-secondary)] mt-2">Most used calculators by our users</p>
            </div>
            <Link href="/calculators" className="btn-outline hidden md:flex">
              View All
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredCalculators.map((calc, index) => {
              const category = getCategoryById(calc.category)
              return (
                <Link
                  key={calc.slug}
                  href={`/calculators/${calc.slug}`}
                  className="card card-hover group animate-slide-up"
                  style={{ animationDelay: `${index * 100}ms` }}
                >
                  <div className="flex items-start gap-4">
                    <span className="text-3xl">{calc.icon || category?.icon}</span>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold text-[var(--color-text-primary)] group-hover:text-primary-500 transition-colors">
                        {calc.title}
                      </h3>
                      <p className="text-sm text-[var(--color-text-secondary)] mt-1 line-clamp-2">
                        {calc.description}
                      </p>
                      <span className={`badge badge-${calc.category} mt-3`}>
                        {category?.name}
                      </span>
                    </div>
                    <svg 
                      className="w-5 h-5 text-[var(--color-text-muted)] group-hover:text-primary-500 group-hover:translate-x-1 transition-all flex-shrink-0"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                  </div>
                </Link>
              )
            })}
          </div>

          <div className="mt-8 text-center md:hidden">
            <Link href="/calculators" className="btn-primary">
              View All Calculators
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="section bg-[var(--color-bg-primary)]">
        <div className="container-app">
          <div className="text-center mb-12">
            <h2 className="section-title">Why Choose MicroCalc?</h2>
            <p className="section-subtitle">Built for accuracy, speed, and ease of use</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                icon: '⚡',
                title: 'Lightning Fast',
                description: 'Instant calculations with no page reloads. Results appear the moment you click Calculate.',
              },
              {
                icon: '🎯',
                title: 'Accurate Results',
                description: 'Industry-standard formulas and algorithms ensure precise calculations every time.',
              },
              {
                icon: '📱',
                title: 'Mobile Friendly',
                description: 'Fully responsive design works perfectly on phones, tablets, and desktops.',
              },
              {
                icon: '🔒',
                title: 'Private & Secure',
                description: 'All calculations happen in your browser. Your data never leaves your device.',
              },
            ].map((feature, index) => (
              <div 
                key={feature.title} 
                className="text-center p-6 animate-slide-up"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <span className="text-4xl mb-4 block">{feature.icon}</span>
                <h3 className="font-semibold text-[var(--color-text-primary)] mb-2">
                  {feature.title}
                </h3>
                <p className="text-sm text-[var(--color-text-secondary)]">
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Ad Placeholder */}
      <section className="py-6 bg-[var(--color-bg-secondary)]">
        <div className="container-app">
          <ResponsiveAd />
        </div>
      </section>

      {/* All Calculators by Category */}
      <section className="section bg-[var(--color-bg-primary)]">
        <div className="container-app">
          <div className="text-center mb-12">
            <h2 className="section-title">All Calculators</h2>
            <p className="section-subtitle">Explore our complete collection</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {CATEGORIES.map((category) => {
              const calculators = getAllCalculators()
                .filter((c) => c.category === category.id)
                .slice(0, 6)

              return (
                <div key={category.id} className="card">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="flex items-center gap-2 font-semibold text-lg text-[var(--color-text-primary)]">
                      <span>{category.icon}</span>
                      {category.name}
                    </h3>
                    <Link
                      href={`/category/${category.slug}`}
                      className="text-sm text-primary-500 hover:text-primary-600"
                    >
                      View all →
                    </Link>
                  </div>
                  <ul className="space-y-2">
                    {calculators.map((calc) => (
                      <li key={calc.slug}>
                        <Link
                          href={`/calculators/${calc.slug}`}
                          className="flex items-center gap-2 text-[var(--color-text-secondary)] hover:text-primary-500 transition-colors"
                        >
                          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                          </svg>
                          {calc.title}
                        </Link>
                      </li>
                    ))}
                  </ul>
                </div>
              )
            })}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-primary-500 to-primary-600">
        <div className="container-app text-center">
          <h2 className="text-2xl md:text-3xl font-bold text-white mb-4">
            Can't Find What You Need?
          </h2>
          <p className="text-primary-100 mb-8 max-w-2xl mx-auto">
            We're constantly adding new calculators. Let us know what you'd like to see,
            or try our search to find existing tools.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/calculators" className="btn bg-white text-primary-600 hover:bg-primary-50">
              Browse All Calculators
            </Link>
            <Link href="/contact" className="btn border-2 border-white text-white hover:bg-white/10">
              Request a Calculator
            </Link>
          </div>
        </div>
      </section>
    </>
  )
}
