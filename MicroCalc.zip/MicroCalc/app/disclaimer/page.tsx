import { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Disclaimer',
  description: 'Disclaimer for MicroCalc calculator tools and results.',
  alternates: {
    canonical: '/disclaimer',
  },
}

export default function DisclaimerPage() {
  return (
    <main className="container-app py-8">
      <div className="max-w-3xl mx-auto">
        <h1 className="text-3xl font-bold text-[var(--color-text-primary)] mb-8">
          Disclaimer
        </h1>

        <div className="prose-calc space-y-6">
          <div className="bg-yellow-50 dark:bg-yellow-900/30 border border-yellow-200 dark:border-yellow-800 rounded-lg p-6">
            <h2 className="text-yellow-800 dark:text-yellow-200 mt-0">Important Notice</h2>
            <p className="text-yellow-700 dark:text-yellow-300 mb-0">
              The calculators and tools provided on MicroCalc are for <strong>informational and educational purposes only</strong>. 
              They should not be used as the sole basis for making financial, medical, legal, or other important decisions.
            </p>
          </div>

          <section>
            <h2>General Disclaimer</h2>
            <p>
              MicroCalc provides free online calculators as a convenience to users. While we strive to ensure 
              accuracy, we make no warranties or representations regarding the accuracy, reliability, or completeness 
              of any calculation results.
            </p>
          </section>

          <section>
            <h2>Not Professional Advice</h2>
            <p>The information and calculations provided by our tools do not constitute:</p>
            <ul>
              <li>Financial or investment advice</li>
              <li>Medical or health advice</li>
              <li>Legal or tax advice</li>
              <li>Professional accounting advice</li>
              <li>Any other form of professional counsel</li>
            </ul>
            <p>
              Always consult with qualified professionals before making important decisions that could affect 
              your finances, health, or legal standing.
            </p>
          </section>

          <section>
            <h2>Accuracy of Results</h2>
            <p>
              Calculator results are based on the information you provide and standard mathematical formulas. 
              Results may differ from actual outcomes due to:
            </p>
            <ul>
              <li>Rounding and computational limitations</li>
              <li>Simplified assumptions in formulas</li>
              <li>Variations in real-world conditions</li>
              <li>Changes in rates, laws, or regulations</li>
              <li>User input errors</li>
            </ul>
          </section>

          <section>
            <h2>Financial Calculators</h2>
            <p>
              Our financial calculators (mortgage, loan, investment, etc.) provide estimates based on general 
              assumptions. Actual loan terms, interest rates, and payments may vary based on your credit score, 
              lender policies, and other factors. Always confirm calculations with your financial institution.
            </p>
          </section>

          <section>
            <h2>Health Calculators</h2>
            <p>
              Health-related calculators (BMI, calorie, etc.) provide general estimates and are not a substitute 
              for professional medical evaluation. Results may not account for individual health conditions, 
              medications, or other factors. Consult healthcare providers for personalized health advice.
            </p>
          </section>

          <section>
            <h2>Limitation of Liability</h2>
            <p>
              MicroCalc and its operators shall not be held liable for any damages or losses arising from:
            </p>
            <ul>
              <li>Use of or reliance on calculator results</li>
              <li>Decisions made based on calculations</li>
              <li>Errors or inaccuracies in results</li>
              <li>Technical issues affecting calculations</li>
            </ul>
          </section>

          <section>
            <h2>Your Responsibility</h2>
            <p>
              By using our calculators, you acknowledge that you understand and accept this disclaimer. 
              You agree to verify important calculations through appropriate professional sources and 
              take full responsibility for any decisions made using our tools.
            </p>
          </section>

          <section>
            <h2>Questions</h2>
            <p>
              If you have questions about this disclaimer or our calculators, please contact us 
              through our website.
            </p>
          </section>
        </div>
      </div>
    </main>
  )
}

