import { Metadata } from 'next';
import { notFound } from 'next/navigation';
import Link from 'next/link';
import { getCalculatorsByCategory, getCategoriesWithCounts } from '@/lib/calculators';
import { CATEGORIES, CATEGORY_COLORS } from '@/lib/constants';
import { generatePageMetadata, JsonLd, generateBreadcrumbSchema } from '@/components/SEO';
import AdPlaceholder from '@/components/AdPlaceholder';
import { cn } from '@/lib/utils';
import { CalculatorCategory } from '@/types/calculator';

interface PageProps {
  params: Promise<{ category: string }>;
}

// Generate static params for all categories
export async function generateStaticParams() {
  return CATEGORIES.map((category) => ({ category: category.id }));
}

// Generate metadata
export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const resolvedParams = await params;
  const category = CATEGORIES.find((c) => c.id === resolvedParams.category);
  
  if (!category) {
    return { title: 'Category Not Found' };
  }

  return generatePageMetadata({
    title: `${category.name} Calculators - Free Online Tools`,
    description: `${category.description}. Use our free ${category.name.toLowerCase()} calculators for accurate results.`,
    path: `/categories/${category.id}`,
    keywords: [`${category.name.toLowerCase()} calculator`, `free ${category.name.toLowerCase()} calculators`, 'online calculator'],
  });
}

export default async function CategoryPage({ params }: PageProps) {
  const resolvedParams = await params;
  const category = CATEGORIES.find((c) => c.id === resolvedParams.category);

  if (!category) {
    notFound();
  }

  const calculators = getCalculatorsByCategory(category.id as CalculatorCategory);
  const allCategories = getCategoriesWithCounts();

  const breadcrumbs = [
    { name: 'Home', url: '/' },
    { name: category.name, url: `/categories/${category.id}` },
  ];

  return (
    <>
      <JsonLd data={generateBreadcrumbSchema(breadcrumbs)} />

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary-50 to-white dark:from-surface-900 dark:to-surface-900">
        <div className="container-wide py-12">
          <nav aria-label="Breadcrumb" className="mb-6">
            <ol className="flex items-center gap-2 text-sm">
              <li>
                <Link href="/" className="text-primary-600 dark:text-primary-400 hover:underline">
                  Home
                </Link>
              </li>
              <li className="flex items-center gap-2">
                <svg className="w-4 h-4 text-surface-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
                <span className="text-surface-600 dark:text-surface-400">{category.name}</span>
              </li>
            </ol>
          </nav>

          <div className="flex items-center gap-4 mb-6">
            <div className="text-5xl">{category.icon}</div>
            <div>
              <h1 className="text-3xl md:text-4xl font-bold text-surface-900 dark:text-white">
                {category.name} Calculators
              </h1>
              <p className="text-surface-600 dark:text-surface-400 mt-2">
                {category.description}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-4 text-sm">
            <span className={cn('badge', CATEGORY_COLORS[category.id])}>
              {calculators.length} calculators
            </span>
            <span className="text-surface-500 dark:text-surface-400">
              {calculators.filter(c => c.implemented).length} fully functional
            </span>
          </div>
        </div>
      </section>

      <div className="container-wide py-8">
        <div className="grid lg:grid-cols-[1fr,280px] gap-8">
          {/* Calculator Grid */}
          <div>
            {/* Ad */}
            <AdPlaceholder slot="header" className="mb-8" />

            <div className="grid sm:grid-cols-2 gap-6">
              {calculators.map((calc) => (
                <Link
                  key={calc.slug}
                  href={`/calculators/${calc.slug}`}
                  className="card card-hover p-6 group"
                >
                  <div className="flex items-start justify-between mb-3">
                    <h2 className="text-lg font-semibold text-surface-900 dark:text-white group-hover:text-primary-600 dark:group-hover:text-primary-400 transition-colors">
                      {calc.name}
                    </h2>
                    {calc.implemented && (
                      <span className="flex-shrink-0 w-2 h-2 rounded-full bg-green-500" title="Fully functional" />
                    )}
                  </div>
                  <p className="text-sm text-surface-600 dark:text-surface-400 mb-4 line-clamp-2">
                    {calc.description}
                  </p>
                  <div className="flex items-center justify-between">
                    <span className="text-primary-600 dark:text-primary-400 text-sm font-medium group-hover:underline">
                      Use Calculator →
                    </span>
                  </div>
                </Link>
              ))}
            </div>

            {/* Footer Ad */}
            <AdPlaceholder slot="footer" className="mt-8" />
          </div>

          {/* Sidebar */}
          <aside className="space-y-6">
            {/* Other Categories */}
            <div className="card p-6 sticky top-24">
              <h3 className="text-lg font-semibold text-surface-900 dark:text-white mb-4">
                Other Categories
              </h3>
              <div className="space-y-2">
                {allCategories
                  .filter((c) => c.id !== category.id)
                  .map((cat) => (
                    <Link
                      key={cat.id}
                      href={`/categories/${cat.id}`}
                      className="flex items-center gap-3 p-3 rounded-lg hover:bg-surface-50 dark:hover:bg-surface-800 transition-colors"
                    >
                      <span className="text-2xl">{cat.icon}</span>
                      <div className="flex-1">
                        <div className="font-medium text-surface-900 dark:text-white">
                          {cat.name}
                        </div>
                        <div className="text-xs text-surface-500 dark:text-surface-400">
                          {cat.calculatorCount} calculators
                        </div>
                      </div>
                    </Link>
                  ))}
              </div>
            </div>

            {/* Sidebar Ad */}
            <AdPlaceholder slot="sidebar" />
          </aside>
        </div>
      </div>
    </>
  );
}

