import '../globals.css'
import { ThemeProvider } from '@/components/providers/ThemeProvider'

export default function EmbedLayout({
  children,
}: {
  children: React.ReactNode
}) {
  // Embed layout without header/footer
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <meta name="robots" content="noindex,nofollow" />
      </head>
      <body className="bg-transparent">
        <ThemeProvider>
          {children}
        </ThemeProvider>
      </body>
    </html>
  )
}

