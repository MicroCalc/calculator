import { Metadata } from 'next'
import { notFound } from 'next/navigation'
import { getCalculatorBySlug, getAllCalculatorSlugs } from '@/lib/calculators'
import { EmbedCalculator } from '@/components/calculator/EmbedCalculator'

interface PageProps {
  params: { slug: string }
}

export async function generateStaticParams() {
  const slugs = getAllCalculatorSlugs()
  return slugs.map((slug) => ({ slug }))
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const calculator = getCalculatorBySlug(params.slug)
  
  if (!calculator) {
    return { title: 'Calculator Not Found' }
  }

  return {
    title: `${calculator.title} - Embed Widget`,
    description: calculator.description,
    robots: {
      index: false,
      follow: false,
    },
  }
}

export default function EmbedPage({ params }: PageProps) {
  const calculator = getCalculatorBySlug(params.slug)

  if (!calculator) {
    notFound()
  }

  return (
    <div className="embed-mode min-h-screen p-4">
      <EmbedCalculator spec={calculator} />
    </div>
  )
}
