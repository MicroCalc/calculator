import { Metadata } from 'next'
import { notFound } from 'next/navigation'
import Link from 'next/link'
import { getCalculatorsByCategory } from '@/lib/calculators'
import { CATEGORIES, getCategoryBySlug, CATEGORY_COLORS } from '@/lib/constants'
import { ResponsiveAd } from '@/components/ads/AdPlaceholder'
import { JsonLdBreadcrumbs } from '@/components/seo/JsonLd'

interface PageProps {
  params: { slug: string }
}

export async function generateStaticParams() {
  return CATEGORIES.map((category) => ({
    slug: category.slug,
  }))
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const category = getCategoryBySlug(params.slug)
  
  if (!category) {
    return { title: 'Category Not Found' }
  }

  return {
    title: `${category.name} Calculators - Free Online Tools`,
    description: `${category.description} Browse our free ${category.name.toLowerCase()} calculators.`,
    alternates: {
      canonical: `/category/${category.slug}`,
    },
  }
}

export default function CategoryPage({ params }: PageProps) {
  const category = getCategoryBySlug(params.slug)

  if (!category) {
    notFound()
  }

  const calculators = getCalculatorsByCategory(category.id)

  const breadcrumbs = [
    { name: 'Home', url: '/' },
    { name: 'Categories', url: '/calculators' },
    { name: category.name, url: `/category/${category.slug}` },
  ]

  return (
    <>
      <JsonLdBreadcrumbs items={breadcrumbs} />

      {/* Header */}
      <header className="bg-gradient-to-br from-[var(--color-bg-secondary)] to-[var(--color-bg-primary)] py-12 border-b border-[var(--color-border)]">
        <div className="container-app">
          {/* Breadcrumbs */}
          <nav className="mb-6" aria-label="Breadcrumb">
            <ol className="flex items-center gap-2 text-sm">
              {breadcrumbs.map((crumb, index) => (
                <li key={crumb.url} className="flex items-center gap-2">
                  {index > 0 && (
                    <svg className="w-4 h-4 text-[var(--color-text-muted)]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                  )}
                  {index === breadcrumbs.length - 1 ? (
                    <span className="text-[var(--color-text-muted)]">{crumb.name}</span>
                  ) : (
                    <Link href={crumb.url} className="text-primary-500 hover:text-primary-600">
                      {crumb.name}
                    </Link>
                  )}
                </li>
              ))}
            </ol>
          </nav>

          <div className="flex items-center gap-4">
            <span className="text-5xl">{category.icon}</span>
            <div>
              <h1 className="text-3xl md:text-4xl font-bold text-[var(--color-text-primary)]">
                {category.name} Calculators
              </h1>
              <p className="text-lg text-[var(--color-text-secondary)] mt-2">
                {category.description}
              </p>
              <p className="text-sm text-[var(--color-text-muted)] mt-1">
                {calculators.length} calculators available
              </p>
            </div>
          </div>
        </div>
      </header>

      <main className="container-app py-8">
        {/* Ad */}
        <div className="mb-8">
          <ResponsiveAd />
        </div>

        {/* Calculator Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {calculators.map((calc, index) => (
            <Link
              key={calc.slug}
              href={`/calculators/${calc.slug}`}
              className="card card-hover group animate-slide-up"
              style={{ animationDelay: `${index * 50}ms` }}
            >
              <div className="flex items-start gap-4">
                <span className="text-3xl flex-shrink-0">{calc.icon || category.icon}</span>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <h2 className="font-semibold text-[var(--color-text-primary)] group-hover:text-primary-500 transition-colors">
                      {calc.title}
                    </h2>
                    {calc.isImplemented && (
                      <span className="px-1.5 py-0.5 text-xs bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300 rounded">
                        Live
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-[var(--color-text-secondary)] line-clamp-2">
                    {calc.description}
                  </p>
                </div>
                <svg
                  className="w-5 h-5 text-[var(--color-text-muted)] group-hover:text-primary-500 group-hover:translate-x-1 transition-all flex-shrink-0 mt-1"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </div>
            </Link>
          ))}
        </div>

        {/* Other Categories */}
        <section className="mt-16">
          <h2 className="text-xl font-semibold text-[var(--color-text-primary)] mb-6">
            Other Categories
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {CATEGORIES.filter(c => c.id !== category.id).map((cat) => (
              <Link
                key={cat.id}
                href={`/category/${cat.slug}`}
                className="card card-hover text-center p-4"
              >
                <span className="text-2xl block mb-2">{cat.icon}</span>
                <span className="text-sm font-medium text-[var(--color-text-primary)]">
                  {cat.name}
                </span>
              </Link>
            ))}
          </div>
        </section>

        {/* Ad */}
        <div className="mt-12">
          <ResponsiveAd />
        </div>
      </main>
    </>
  )
}

