import { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Cookie Policy',
  description: 'Cookie policy for MicroCalc - how we use cookies and similar technologies.',
  alternates: {
    canonical: '/cookies',
  },
}

export default function CookiesPage() {
  return (
    <main className="container-app py-8">
      <div className="max-w-3xl mx-auto">
        <h1 className="text-3xl font-bold text-[var(--color-text-primary)] mb-8">
          Cookie Policy
        </h1>

        <div className="prose-calc space-y-8">
          <p className="text-lg text-[var(--color-text-secondary)]">
            Last updated: {new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
          </p>

          <section>
            <h2>What Are Cookies?</h2>
            <p>
              Cookies are small text files stored on your device when you visit a website. 
              They help websites remember your preferences and improve your browsing experience.
            </p>
          </section>

          <section>
            <h2>How We Use Cookies</h2>
            <p>MicroCalc uses cookies for the following purposes:</p>
            
            <h3>Essential Cookies</h3>
            <p>These cookies are necessary for the website to function properly:</p>
            <ul>
              <li><strong>Theme preference:</strong> Remembers your dark/light mode choice</li>
              <li><strong>Session data:</strong> Maintains your session while using the site</li>
            </ul>

            <h3>Analytics Cookies</h3>
            <p>We use Google Analytics to understand how visitors use our site:</p>
            <ul>
              <li>Pages visited and time spent</li>
              <li>Device and browser information</li>
              <li>Geographic location (country/region)</li>
              <li>Which calculators are most popular</li>
            </ul>
            <p>
              This data is anonymized and helps us improve our calculators and user experience. 
              You can opt out of Google Analytics by installing the{' '}
              <a 
                href="https://tools.google.com/dlpage/gaoptout" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-primary-500 hover:underline"
              >
                Google Analytics Opt-out Browser Add-on
              </a>.
            </p>

            <h3>Advertising Cookies (When Enabled)</h3>
            <p>
              If advertising is enabled, Google AdSense may use cookies to display relevant ads. 
              These cookies collect information about your browsing habits across different websites.
            </p>
          </section>

          <section>
            <h2>Managing Cookies</h2>
            <p>You can control cookies through your browser settings:</p>
            <ul>
              <li><strong>Chrome:</strong> Settings → Privacy and security → Cookies</li>
              <li><strong>Firefox:</strong> Options → Privacy &amp; Security → Cookies</li>
              <li><strong>Safari:</strong> Preferences → Privacy → Cookies</li>
              <li><strong>Edge:</strong> Settings → Privacy, search, and services → Cookies</li>
            </ul>
            <p>
              Note that blocking all cookies may affect website functionality, including your 
              theme preferences.
            </p>
          </section>

          <section>
            <h2>Third-Party Cookies</h2>
            <p>
              Some cookies are set by third-party services we use. These services have their 
              own privacy policies:
            </p>
            <ul>
              <li>
                <a 
                  href="https://policies.google.com/privacy" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-primary-500 hover:underline"
                >
                  Google Privacy Policy
                </a> (Analytics &amp; AdSense)
              </li>
              <li>
                <a 
                  href="https://vercel.com/legal/privacy-policy" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-primary-500 hover:underline"
                >
                  Vercel Privacy Policy
                </a> (Hosting)
              </li>
            </ul>
          </section>

          <section>
            <h2>Updates to This Policy</h2>
            <p>
              We may update this cookie policy as our practices change. Any updates will be 
              posted on this page with a revised date.
            </p>
          </section>

          <section>
            <h2>Contact</h2>
            <p>
              For questions about our cookie practices, please see our{' '}
              <a href="/contact" className="text-primary-500 hover:underline">contact page</a>.
            </p>
          </section>
        </div>
      </div>
    </main>
  )
}

