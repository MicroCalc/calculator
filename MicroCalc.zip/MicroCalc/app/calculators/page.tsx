import { Metadata } from 'next'
import Link from 'next/link'
import { getAllCalculators } from '@/lib/calculators'
import { CATEGORIES, getCategoryById, CATEGORY_COLORS } from '@/lib/constants'
import { ResponsiveAd } from '@/components/ads/AdPlaceholder'

export const metadata: Metadata = {
  title: 'All Calculators - Free Online Tools',
  description: 'Browse our complete collection of 40+ free online calculators for finance, health, math, dates, and conversions.',
  alternates: {
    canonical: '/calculators',
  },
}

export default function CalculatorsPage() {
  const allCalculators = getAllCalculators()
  const calculatorsByCategory = CATEGORIES.map(category => ({
    category,
    calculators: allCalculators.filter(calc => calc.category === category.id),
  }))

  return (
    <main className="container-app py-8">
      {/* Header */}
      <header className="text-center mb-12">
        <h1 className="text-3xl md:text-4xl font-bold text-[var(--color-text-primary)] mb-4">
          All Calculators
        </h1>
        <p className="text-lg text-[var(--color-text-secondary)] max-w-2xl mx-auto">
          Browse our complete collection of {allCalculators.length}+ free online calculators
          organized by category.
        </p>
      </header>

      {/* Category Filter */}
      <div className="flex flex-wrap gap-2 justify-center mb-8">
        <a
          href="#all"
          className="px-4 py-2 rounded-full bg-primary-500 text-white text-sm font-medium"
        >
          All ({allCalculators.length})
        </a>
        {CATEGORIES.map(category => {
          const count = allCalculators.filter(c => c.category === category.id).length
          return (
            <a
              key={category.id}
              href={`#${category.slug}`}
              className="px-4 py-2 rounded-full bg-[var(--color-bg-tertiary)] text-[var(--color-text-secondary)] text-sm font-medium hover:bg-[var(--color-border)] transition-colors"
            >
              {category.icon} {category.name} ({count})
            </a>
          )
        })}
      </div>

      {/* Ad */}
      <div className="mb-8">
        <ResponsiveAd />
      </div>

      {/* Calculators by Category */}
      <div className="space-y-12" id="all">
        {calculatorsByCategory.map(({ category, calculators }) => (
          <section key={category.id} id={category.slug}>
            <div className="flex items-center gap-3 mb-6">
              <span className="text-3xl">{category.icon}</span>
              <div>
                <h2 className="text-2xl font-bold text-[var(--color-text-primary)]">
                  {category.name}
                </h2>
                <p className="text-sm text-[var(--color-text-secondary)]">
                  {category.description}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {calculators.map(calc => {
                const colors = CATEGORY_COLORS[calc.category]
                return (
                  <Link
                    key={calc.slug}
                    href={`/calculators/${calc.slug}`}
                    className="card card-hover group"
                  >
                    <div className="flex items-start gap-3">
                      <span className="text-2xl flex-shrink-0">
                        {calc.icon || category.icon}
                      </span>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <h3 className="font-semibold text-[var(--color-text-primary)] group-hover:text-primary-500 transition-colors">
                            {calc.shortTitle || calc.title}
                          </h3>
                          {calc.isImplemented && (
                            <span className="px-1.5 py-0.5 text-xs bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300 rounded">
                              Live
                            </span>
                          )}
                        </div>
                        <p className="text-sm text-[var(--color-text-secondary)] mt-1 line-clamp-2">
                          {calc.description}
                        </p>
                      </div>
                      <svg
                        className="w-5 h-5 text-[var(--color-text-muted)] group-hover:text-primary-500 group-hover:translate-x-1 transition-all flex-shrink-0"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                      </svg>
                    </div>
                  </Link>
                )
              })}
            </div>
          </section>
        ))}
      </div>

      {/* Bottom Ad */}
      <div className="mt-12">
        <ResponsiveAd />
      </div>
    </main>
  )
}

