import { Metadata } from 'next'
import { notFound } from 'next/navigation'
import Link from 'next/link'
import { getCalculatorBySlug, getAllCalculatorSlugs, getRelatedCalculators } from '@/lib/calculators'
import { getCategoryById } from '@/lib/constants'
import { CalculatorRenderer } from '@/components/calculator/CalculatorRenderer'
import { ResponsiveAd, SidebarAd } from '@/components/ads/AdPlaceholder'
import { JsonLdFAQ, JsonLdCalculator, JsonLdBreadcrumbs, JsonLdHowTo } from '@/components/seo/JsonLd'

interface PageProps {
  params: { slug: string }
}

// Generate static params for all calculators
export async function generateStaticParams() {
  const slugs = getAllCalculatorSlugs()
  return slugs.map((slug) => ({ slug }))
}

// Generate metadata for SEO
export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const calculator = getCalculatorBySlug(params.slug)
  
  if (!calculator) {
    return { title: 'Calculator Not Found' }
  }

  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || 'https://microcalc.app'

  return {
    title: calculator.seo.title,
    description: calculator.seo.description,
    keywords: calculator.seo.keywords,
    alternates: {
      canonical: `/calculators/${calculator.slug}`,
    },
    openGraph: {
      title: calculator.seo.title,
      description: calculator.seo.description,
      url: `${siteUrl}/calculators/${calculator.slug}`,
      type: 'website',
      images: [
        {
          url: calculator.seo.ogImage || '/og-image.png',
          width: 1200,
          height: 630,
          alt: calculator.title,
        },
      ],
    },
    twitter: {
      card: 'summary_large_image',
      title: calculator.seo.title,
      description: calculator.seo.description,
    },
  }
}

export default function CalculatorPage({ params }: PageProps) {
  const calculator = getCalculatorBySlug(params.slug)

  if (!calculator) {
    notFound()
  }

  const category = getCategoryById(calculator.category)
  const relatedCalculators = getRelatedCalculators(params.slug, 4)

  const breadcrumbs = [
    { name: 'Home', url: '/' },
    { name: category?.name || 'Calculators', url: `/category/${category?.slug}` },
    { name: calculator.title, url: `/calculators/${calculator.slug}` },
  ]

  const howToSteps = [
    { name: 'Enter Values', text: 'Fill in the required input fields with your data.' },
    { name: 'Click Calculate', text: 'Press the Calculate button to process your inputs.' },
    { name: 'View Results', text: 'See your calculated results displayed below the inputs.' },
    { name: 'Share or Save', text: 'Copy results, share on social media, or print for your records.' },
  ]

  return (
    <>
      {/* JSON-LD Structured Data */}
      <JsonLdBreadcrumbs items={breadcrumbs} />
      <JsonLdCalculator
        name={calculator.title}
        description={calculator.description}
        url={`/calculators/${calculator.slug}`}
        category={category?.name || 'Calculator'}
      />
      <JsonLdFAQ faqs={calculator.faq} />
      <JsonLdHowTo
        name={`How to Use ${calculator.title}`}
        description={`Step-by-step guide to using the ${calculator.title}`}
        steps={howToSteps}
      />

      {/* Breadcrumbs */}
      <nav className="bg-[var(--color-bg-secondary)] border-b border-[var(--color-border)]" aria-label="Breadcrumb">
        <div className="container-app py-3">
          <ol className="flex items-center gap-2 text-sm">
            {breadcrumbs.map((crumb, index) => (
              <li key={crumb.url} className="flex items-center gap-2">
                {index > 0 && (
                  <svg className="w-4 h-4 text-[var(--color-text-muted)]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                )}
                {index === breadcrumbs.length - 1 ? (
                  <span className="text-[var(--color-text-muted)]">{crumb.name}</span>
                ) : (
                  <Link href={crumb.url} className="text-primary-500 hover:text-primary-600">
                    {crumb.name}
                  </Link>
                )}
              </li>
            ))}
          </ol>
        </div>
      </nav>

      {/* Main Content */}
      <main className="container-app py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Main column */}
          <div className="lg:col-span-3">
            {/* Header */}
            <header className="mb-8">
              <div className="flex items-start gap-4 mb-4">
                <span className="text-4xl">{calculator.icon || category?.icon}</span>
                <div>
                  <span className={`badge badge-${calculator.category} mb-2`}>
                    {category?.name}
                  </span>
                  <h1 className="text-3xl md:text-4xl font-bold text-[var(--color-text-primary)]">
                    {calculator.title}
                  </h1>
                </div>
              </div>
              <p className="text-lg text-[var(--color-text-secondary)] prose-calc">
                {calculator.introduction}
              </p>
            </header>

            {/* Ad Placeholder */}
            <div className="mb-8 no-print">
              <ResponsiveAd />
            </div>

            {/* Calculator */}
            <section aria-label="Calculator">
              <CalculatorRenderer spec={calculator} />
            </section>

            {/* Example */}
            {calculator.examples.length > 0 && (
              <section className="mt-12" aria-labelledby="example-heading">
                <h2 id="example-heading" className="text-xl font-semibold text-[var(--color-text-primary)] mb-4">
                  Example Calculation
                </h2>
                <div className="card bg-[var(--color-bg-secondary)]">
                  <h3 className="font-medium text-[var(--color-text-primary)] mb-2">
                    {calculator.examples[0].title}
                  </h3>
                  <p className="text-[var(--color-text-secondary)] text-sm mb-4">
                    {calculator.examples[0].description}
                  </p>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="font-medium text-[var(--color-text-muted)] mb-2">Inputs:</p>
                      <ul className="space-y-1">
                        {Object.entries(calculator.examples[0].inputs).map(([key, value]) => (
                          <li key={key} className="text-[var(--color-text-secondary)]">
                            {key}: <span className="font-medium">{String(value)}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                    <div>
                      <p className="font-medium text-[var(--color-text-muted)] mb-2">Expected Results:</p>
                      <ul className="space-y-1">
                        {Object.entries(calculator.examples[0].expectedOutputs).map(([key, value]) => (
                          <li key={key} className="text-[var(--color-text-secondary)]">
                            {key}: <span className="font-medium">{String(value)}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              </section>
            )}

            {/* Formula Section */}
            {calculator.formula && (
              <section className="mt-12" aria-labelledby="formula-heading">
                <h2 id="formula-heading" className="text-xl font-semibold text-[var(--color-text-primary)] mb-4">
                  Formula & Calculation Method
                </h2>
                <div className="prose-calc">
                  <p className="mb-4">{calculator.formula.description}</p>
                  {calculator.formula.formula && (
                    <div className="formula-box mb-4">
                      <code>{calculator.formula.formula}</code>
                    </div>
                  )}
                  {calculator.formula.variables && calculator.formula.variables.length > 0 && (
                    <div className="mt-4">
                      <p className="font-medium mb-2">Variables:</p>
                      <ul className="space-y-1">
                        {calculator.formula.variables.map((v) => (
                          <li key={v.name}>
                            <code className="text-primary-600 dark:text-primary-400">{v.name}</code>: {v.description}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              </section>
            )}

            {/* How to Use */}
            {calculator.howToUse && (
              <section className="mt-12" aria-labelledby="howto-heading">
                <h2 id="howto-heading" className="text-xl font-semibold text-[var(--color-text-primary)] mb-4">
                  How to Use This Calculator
                </h2>
                <div className="prose-calc whitespace-pre-line">
                  {calculator.howToUse}
                </div>
              </section>
            )}

            {/* FAQ Section */}
            {calculator.faq.length > 0 && (
              <section className="mt-12" aria-labelledby="faq-heading">
                <h2 id="faq-heading" className="text-xl font-semibold text-[var(--color-text-primary)] mb-6">
                  Frequently Asked Questions
                </h2>
                <div className="space-y-4">
                  {calculator.faq.map((item, index) => (
                    <details
                      key={index}
                      className="group card"
                    >
                      <summary className="flex items-center justify-between cursor-pointer list-none font-medium text-[var(--color-text-primary)]">
                        {item.question}
                        <svg
                          className="w-5 h-5 text-[var(--color-text-muted)] group-open:rotate-180 transition-transform"
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                        >
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                        </svg>
                      </summary>
                      <p className="mt-4 text-[var(--color-text-secondary)]">
                        {item.answer}
                      </p>
                    </details>
                  ))}
                </div>
              </section>
            )}

            {/* Related Calculators */}
            {relatedCalculators.length > 0 && (
              <section className="mt-12" aria-labelledby="related-heading">
                <h2 id="related-heading" className="text-xl font-semibold text-[var(--color-text-primary)] mb-6">
                  Related Calculators
                </h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {relatedCalculators.map((calc) => {
                    const calcCategory = getCategoryById(calc.category)
                    return (
                      <Link
                        key={calc.slug}
                        href={`/calculators/${calc.slug}`}
                        className="card card-hover flex items-center gap-3"
                      >
                        <span className="text-2xl">{calc.icon || calcCategory?.icon}</span>
                        <div>
                          <h3 className="font-medium text-[var(--color-text-primary)]">
                            {calc.title}
                          </h3>
                          <p className="text-sm text-[var(--color-text-muted)] line-clamp-1">
                            {calc.description}
                          </p>
                        </div>
                      </Link>
                    )
                  })}
                </div>
              </section>
            )}

            {/* Ad Placeholder */}
            <div className="mt-12 no-print">
              <ResponsiveAd />
            </div>
          </div>

          {/* Sidebar */}
          <aside className="lg:col-span-1 space-y-6 no-print">
            <SidebarAd />
            
            {/* Quick Links */}
            <div className="card">
              <h3 className="font-semibold text-[var(--color-text-primary)] mb-4">
                On This Page
              </h3>
              <nav>
                <ul className="space-y-2 text-sm">
                  <li>
                    <a href="#" className="text-[var(--color-text-secondary)] hover:text-primary-500">
                      Calculator
                    </a>
                  </li>
                  {calculator.examples.length > 0 && (
                    <li>
                      <a href="#example-heading" className="text-[var(--color-text-secondary)] hover:text-primary-500">
                        Example
                      </a>
                    </li>
                  )}
                  {calculator.formula && (
                    <li>
                      <a href="#formula-heading" className="text-[var(--color-text-secondary)] hover:text-primary-500">
                        Formula
                      </a>
                    </li>
                  )}
                  {calculator.howToUse && (
                    <li>
                      <a href="#howto-heading" className="text-[var(--color-text-secondary)] hover:text-primary-500">
                        How to Use
                      </a>
                    </li>
                  )}
                  {calculator.faq.length > 0 && (
                    <li>
                      <a href="#faq-heading" className="text-[var(--color-text-secondary)] hover:text-primary-500">
                        FAQ
                      </a>
                    </li>
                  )}
                </ul>
              </nav>
            </div>

            {/* Category Quick Links */}
            <div className="card">
              <h3 className="font-semibold text-[var(--color-text-primary)] mb-4">
                {category?.name} Calculators
              </h3>
              <ul className="space-y-2 text-sm">
                {relatedCalculators.slice(0, 5).map((calc) => (
                  <li key={calc.slug}>
                    <Link
                      href={`/calculators/${calc.slug}`}
                      className="text-[var(--color-text-secondary)] hover:text-primary-500"
                    >
                      {calc.title}
                    </Link>
                  </li>
                ))}
                <li>
                  <Link
                    href={`/category/${category?.slug}`}
                    className="text-primary-500 hover:text-primary-600 font-medium"
                  >
                    View all →
                  </Link>
                </li>
              </ul>
            </div>
          </aside>
        </div>
      </main>
    </>
  )
}
