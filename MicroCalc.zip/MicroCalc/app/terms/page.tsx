import { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Terms of Service',
  description: 'Terms of service for using MicroCalc calculators and website.',
  alternates: {
    canonical: '/terms',
  },
}

export default function TermsPage() {
  return (
    <main className="container-app py-8">
      <div className="max-w-3xl mx-auto">
        <h1 className="text-3xl font-bold text-[var(--color-text-primary)] mb-8">
          Terms of Service
        </h1>

        <div className="prose-calc space-y-8">
          <p className="text-lg text-[var(--color-text-secondary)]">
            Last updated: {new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
          </p>

          <section>
            <h2>Acceptance of Terms</h2>
            <p>
              By accessing and using MicroCalc (&quot;the Website&quot;), you agree to be bound by these Terms of Service. 
              If you do not agree to these terms, please do not use our website.
            </p>
          </section>

          <section>
            <h2>Description of Service</h2>
            <p>
              MicroCalc provides free online calculators for finance, health, math, and other purposes. 
              Our calculators are tools designed to assist with calculations and should not be considered 
              professional advice.
            </p>
          </section>

          <section>
            <h2>Disclaimer</h2>
            <p><strong>Important:</strong> The calculators on this website are provided for informational and educational purposes only.</p>
            <ul>
              <li>Results are estimates based on the information you provide</li>
              <li>We do not guarantee the accuracy, completeness, or reliability of any calculations</li>
              <li>Calculator results should not be considered professional financial, medical, legal, or tax advice</li>
              <li>Always consult qualified professionals before making important decisions based on calculator results</li>
              <li>We are not responsible for any decisions made based on calculator outputs</li>
            </ul>
          </section>

          <section>
            <h2>Use of Calculators</h2>
            <p>When using our calculators, you agree to:</p>
            <ul>
              <li>Provide accurate information to the best of your knowledge</li>
              <li>Use calculators for lawful purposes only</li>
              <li>Not attempt to manipulate or exploit calculator functionality</li>
              <li>Not use automated systems to access our calculators excessively</li>
            </ul>
          </section>

          <section>
            <h2>Embedding and Widgets</h2>
            <p>We allow embedding of our calculators on third-party websites under the following conditions:</p>
            <ul>
              <li>The embedding must use our official iframe code</li>
              <li>You may not modify the calculator functionality or appearance</li>
              <li>You may not remove branding or attribution</li>
              <li>The embedding site must not be associated with illegal activities</li>
              <li>We reserve the right to revoke embedding privileges at any time</li>
            </ul>
          </section>

          <section>
            <h2>Intellectual Property</h2>
            <p>
              All content on MicroCalc, including but not limited to text, graphics, logos, calculator designs, 
              and software, is the property of MicroCalc and is protected by copyright and other intellectual 
              property laws.
            </p>
            <p>You may not:</p>
            <ul>
              <li>Copy, modify, or distribute our content without permission</li>
              <li>Use our calculators in a way that suggests endorsement</li>
              <li>Create derivative works based on our calculators</li>
              <li>Reverse engineer our calculator functionality</li>
            </ul>
          </section>

          <section>
            <h2>Limitation of Liability</h2>
            <p>
              To the maximum extent permitted by law, MicroCalc shall not be liable for any indirect, 
              incidental, special, consequential, or punitive damages, including but not limited to:
            </p>
            <ul>
              <li>Loss of profits or revenue</li>
              <li>Loss of data</li>
              <li>Financial losses based on calculator results</li>
              <li>Any other losses resulting from use of our website</li>
            </ul>
          </section>

          <section>
            <h2>Changes to Terms</h2>
            <p>
              We reserve the right to modify these terms at any time. Changes will be effective immediately 
              upon posting to this page. Your continued use of the website after changes constitutes 
              acceptance of the modified terms.
            </p>
          </section>

          <section>
            <h2>Governing Law</h2>
            <p>
              These terms shall be governed by and construed in accordance with applicable laws, 
              without regard to conflict of law principles.
            </p>
          </section>

          <section>
            <h2>Contact</h2>
            <p>
              For questions about these terms, please contact us through our website.
            </p>
            {/* TODO: Add actual contact information */}
            <p className="text-[var(--color-text-muted)]">
              [Contact information to be added]
            </p>
          </section>
        </div>
      </div>
    </main>
  )
}
