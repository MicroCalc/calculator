import { Metadata } from 'next'
import Link from 'next/link'

export const metadata: Metadata = {
  title: 'Contact Us',
  description: 'Get in touch with MicroCalc for questions, suggestions, or partnership inquiries.',
  alternates: {
    canonical: '/contact',
  },
}

export default function ContactPage() {
  return (
    <main className="container-app py-8">
      <div className="max-w-2xl mx-auto">
        <header className="text-center mb-12">
          <span className="text-5xl block mb-4">📬</span>
          <h1 className="text-3xl md:text-4xl font-bold text-[var(--color-text-primary)] mb-4">
            Contact Us
          </h1>
          <p className="text-lg text-[var(--color-text-secondary)]">
            We&apos;d love to hear from you
          </p>
        </header>

        <div className="space-y-8">
          {/* Contact Options */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="card text-center">
              <span className="text-3xl block mb-3">💡</span>
              <h2 className="font-semibold text-[var(--color-text-primary)] mb-2">
                Suggestions
              </h2>
              <p className="text-sm text-[var(--color-text-secondary)] mb-4">
                Have an idea for a new calculator or feature?
              </p>
              <a
                href="mailto:suggestions@microcalc.app"
                className="text-primary-500 hover:underline text-sm"
              >
                suggestions@microcalc.app
              </a>
            </div>

            <div className="card text-center">
              <span className="text-3xl block mb-3">🐛</span>
              <h2 className="font-semibold text-[var(--color-text-primary)] mb-2">
                Bug Reports
              </h2>
              <p className="text-sm text-[var(--color-text-secondary)] mb-4">
                Found an issue with a calculator?
              </p>
              <a
                href="mailto:bugs@microcalc.app"
                className="text-primary-500 hover:underline text-sm"
              >
                bugs@microcalc.app
              </a>
            </div>

            <div className="card text-center">
              <span className="text-3xl block mb-3">🤝</span>
              <h2 className="font-semibold text-[var(--color-text-primary)] mb-2">
                Partnerships
              </h2>
              <p className="text-sm text-[var(--color-text-secondary)] mb-4">
                Interested in embedding or integration?
              </p>
              <a
                href="mailto:partners@microcalc.app"
                className="text-primary-500 hover:underline text-sm"
              >
                partners@microcalc.app
              </a>
            </div>

            <div className="card text-center">
              <span className="text-3xl block mb-3">📧</span>
              <h2 className="font-semibold text-[var(--color-text-primary)] mb-2">
                General
              </h2>
              <p className="text-sm text-[var(--color-text-secondary)] mb-4">
                Other questions or feedback
              </p>
              <a
                href="mailto:hello@microcalc.app"
                className="text-primary-500 hover:underline text-sm"
              >
                hello@microcalc.app
              </a>
            </div>
          </div>

          {/* Note */}
          <div className="card bg-[var(--color-bg-secondary)]">
            <h3 className="font-semibold text-[var(--color-text-primary)] mb-2">
              ℹ️ Note
            </h3>
            <p className="text-sm text-[var(--color-text-secondary)]">
              {/* TODO: Replace placeholder emails with actual contact emails */}
              The email addresses shown above are placeholders. Please update them with your 
              actual contact emails before deploying to production. You can also integrate a 
              contact form using services like Formspree, Netlify Forms, or your own backend.
            </p>
          </div>

          {/* FAQ Link */}
          <div className="text-center">
            <p className="text-[var(--color-text-secondary)] mb-4">
              Before reaching out, you might find answers in our calculator FAQ sections or:
            </p>
            <div className="flex flex-wrap gap-4 justify-center">
              <Link href="/privacy" className="text-primary-500 hover:underline">
                Privacy Policy
              </Link>
              <Link href="/terms" className="text-primary-500 hover:underline">
                Terms of Service
              </Link>
              <Link href="/disclaimer" className="text-primary-500 hover:underline">
                Disclaimer
              </Link>
            </div>
          </div>
        </div>
      </div>
    </main>
  )
}

