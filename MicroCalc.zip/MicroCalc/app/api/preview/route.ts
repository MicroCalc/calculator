import { NextResponse } from 'next/server'
import { getCalculatorBySlug, getAllCalculatorSlugs } from '@/lib/calculators'
import { getCategoryById } from '@/lib/constants'
import type { CalculatorPreview } from '@/types'

/**
 * GET /api/preview
 * Returns calculator metadata for third-party preview cards
 * 
 * Query params:
 * - slug: Calculator slug (optional, returns all if not specified)
 */
export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const slug = searchParams.get('slug')
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || 'https://microcalc.app'

  if (slug) {
    // Return single calculator
    const calculator = getCalculatorBySlug(slug)
    
    if (!calculator) {
      return NextResponse.json(
        { error: 'Calculator not found' },
        { status: 404 }
      )
    }

    const category = getCategoryById(calculator.category)
    const preview: CalculatorPreview = {
      slug: calculator.slug,
      title: calculator.title,
      description: calculator.description,
      category: calculator.category,
      inputs: calculator.inputs.map(input => ({
        id: input.id,
        label: input.label,
        type: input.type,
      })),
      url: `${siteUrl}/calculators/${calculator.slug}`,
      embedUrl: `${siteUrl}/embed/${calculator.slug}`,
    }

    return NextResponse.json(preview)
  }

  // Return all calculators
  const slugs = getAllCalculatorSlugs()
  const previews: CalculatorPreview[] = slugs.map(s => {
    const calc = getCalculatorBySlug(s)!
    return {
      slug: calc.slug,
      title: calc.title,
      description: calc.description,
      category: calc.category,
      inputs: calc.inputs.slice(0, 3).map(input => ({
        id: input.id,
        label: input.label,
        type: input.type,
      })),
      url: `${siteUrl}/calculators/${calc.slug}`,
      embedUrl: `${siteUrl}/embed/${calc.slug}`,
    }
  })

  return NextResponse.json({
    total: previews.length,
    calculators: previews,
  })
}
