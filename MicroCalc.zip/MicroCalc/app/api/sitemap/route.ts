import { NextResponse } from 'next/server';
import { getAllCalculatorsForSitemap } from '@/lib/calculators';
import { CATEGORIES, SITE_CONFIG } from '@/lib/constants';

export async function GET() {
  const baseUrl = SITE_CONFIG.url;
  const calculators = getAllCalculatorsForSitemap();

  // Static pages
  const staticPages = [
    { url: '/', lastmod: new Date().toISOString(), priority: 1.0 },
    { url: '/search', lastmod: new Date().toISOString(), priority: 0.8 },
    { url: '/privacy', lastmod: new Date().toISOString(), priority: 0.3 },
    { url: '/terms', lastmod: new Date().toISOString(), priority: 0.3 },
    { url: '/tools/embed-directory', lastmod: new Date().toISOString(), priority: 0.6 },
  ];

  // Category pages
  const categoryPages = CATEGORIES.map((cat) => ({
    url: `/categories/${cat.id}`,
    lastmod: new Date().toISOString(),
    priority: 0.8,
  }));

  // Calculator pages
  const calculatorPages = calculators.map((calc) => ({
    url: `/calculators/${calc.slug}`,
    lastmod: calc.lastModified,
    priority: calc.priority,
  }));

  // Generate XML
  const urls = [...staticPages, ...categoryPages, ...calculatorPages];

  const sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${urls
  .map(
    (page) => `  <url>
    <loc>${baseUrl}${page.url}</loc>
    <lastmod>${page.lastmod}</lastmod>
    <priority>${page.priority}</priority>
    <changefreq>${page.priority >= 0.8 ? 'weekly' : 'monthly'}</changefreq>
  </url>`
  )
  .join('\n')}
</urlset>`;

  return new NextResponse(sitemap, {
    headers: {
      'Content-Type': 'application/xml',
      'Cache-Control': 'public, max-age=86400, stale-while-revalidate',
    },
  });
}

