import Link from 'next/link'

export default function NotFound() {
  return (
    <main className="container-app py-16 text-center">
      <div className="max-w-md mx-auto">
        <span className="text-6xl block mb-6">🔍</span>
        <h1 className="text-3xl font-bold text-[var(--color-text-primary)] mb-4">
          Page Not Found
        </h1>
        <p className="text-[var(--color-text-secondary)] mb-8">
          Sorry, we couldn&apos;t find the page you&apos;re looking for. 
          It may have been moved or doesn&apos;t exist.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link href="/" className="btn-primary">
            Go Home
          </Link>
          <Link href="/calculators" className="btn-secondary">
            Browse Calculators
          </Link>
        </div>
      </div>
    </main>
  )
}
