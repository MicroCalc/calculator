import { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Privacy Policy',
  description: 'Privacy policy for MicroCalc - how we handle your data and protect your privacy.',
  alternates: {
    canonical: '/privacy',
  },
}

export default function PrivacyPage() {
  return (
    <main className="container-app py-8">
      <div className="max-w-3xl mx-auto">
        <h1 className="text-3xl font-bold text-[var(--color-text-primary)] mb-8">
          Privacy Policy
        </h1>

        <div className="prose-calc space-y-8">
          <p className="text-lg text-[var(--color-text-secondary)]">
            Last updated: {new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
          </p>

          <section>
            <h2>Introduction</h2>
            <p>
              MicroCalc (&quot;we,&quot; &quot;our,&quot; or &quot;us&quot;) respects your privacy and is committed to protecting your personal data. 
              This privacy policy explains how we collect, use, and safeguard your information when you use our website and calculator tools.
            </p>
          </section>

          <section>
            <h2>Information We Collect</h2>
            <h3>Information You Provide</h3>
            <p>
              All calculations are performed client-side in your browser. We do not collect, store, or transmit 
              the numbers or data you enter into our calculators. Your calculation inputs and results remain 
              entirely on your device.
            </p>

            <h3>Automatically Collected Information</h3>
            <p>When you visit our website, we may automatically collect:</p>
            <ul>
              <li>Browser type and version</li>
              <li>Operating system</li>
              <li>Pages visited and time spent</li>
              <li>Referring website</li>
              <li>Approximate geographic location (country/region level)</li>
              <li>Device type (mobile, desktop, tablet)</li>
            </ul>
          </section>

          <section>
            <h2>How We Use Your Information</h2>
            <p>We use the automatically collected information to:</p>
            <ul>
              <li>Analyze website traffic and usage patterns</li>
              <li>Improve our calculators and user experience</li>
              <li>Identify and fix technical issues</li>
              <li>Understand which calculators are most popular</li>
            </ul>
          </section>

          <section>
            <h2>Cookies and Tracking</h2>
            <p>We use the following types of cookies:</p>
            <ul>
              <li><strong>Essential cookies:</strong> Required for the website to function (e.g., dark mode preference)</li>
              <li><strong>Analytics cookies:</strong> Help us understand how visitors use our site (Google Analytics)</li>
              <li><strong>Advertising cookies:</strong> Used to display relevant advertisements (Google AdSense)</li>
            </ul>
            <p>
              You can control cookie preferences through your browser settings. Note that disabling certain 
              cookies may affect website functionality.
            </p>
          </section>

          <section>
            <h2>Third-Party Services</h2>
            <p>We use the following third-party services:</p>
            <ul>
              <li><strong>Google Analytics:</strong> Website analytics and usage tracking</li>
              <li><strong>Google AdSense:</strong> Advertising (when implemented)</li>
              <li><strong>Vercel:</strong> Website hosting</li>
            </ul>
            <p>
              These services may collect their own data as described in their respective privacy policies.
            </p>
          </section>

          <section>
            <h2>Data Security</h2>
            <p>
              We implement appropriate technical and organizational measures to protect your information. 
              However, no internet transmission is completely secure. We cannot guarantee absolute security 
              of data transmitted through our website.
            </p>
          </section>

          <section>
            <h2>Your Rights</h2>
            <p>Depending on your location, you may have rights to:</p>
            <ul>
              <li>Access personal data we hold about you</li>
              <li>Correct inaccurate personal data</li>
              <li>Request deletion of your personal data</li>
              <li>Object to processing of your personal data</li>
              <li>Request restriction of processing</li>
              <li>Data portability</li>
            </ul>
          </section>

          <section>
            <h2>Children&apos;s Privacy</h2>
            <p>
              Our website is not intended for children under 13. We do not knowingly collect personal 
              information from children. If you believe we have collected information from a child, 
              please contact us.
            </p>
          </section>

          <section>
            <h2>Changes to This Policy</h2>
            <p>
              We may update this privacy policy periodically. We will notify you of significant changes 
              by posting the new policy on this page with an updated revision date.
            </p>
          </section>

          <section>
            <h2>Contact Us</h2>
            <p>
              If you have questions about this privacy policy or our data practices, please contact us at:
            </p>
            {/* TODO: Add actual contact email */}
            <p className="text-[var(--color-text-muted)]">
              [Contact email to be added]
            </p>
          </section>
        </div>
      </div>
    </main>
  )
}
