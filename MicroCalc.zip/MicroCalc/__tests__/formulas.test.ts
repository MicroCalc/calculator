import { describe, it, expect } from 'vitest'
import {
  calculateMortgage,
  calculateLoan,
  calculateAutoLoan,
  calculateBMI,
  calculateAge,
  calculateDate,
  calculateSalaryBangladesh,
  calculateFuelCost,
  calculateCompoundInterest,
  calculateScientific,
  executeFormula,
  isFormulaImplemented,
} from '@/lib/formulas'

describe('Formula Registry', () => {
  it('should have all 10 implemented formulas registered', () => {
    const implementedFormulas = [
      'mortgage',
      'loan',
      'autoLoan',
      'bmi',
      'age',
      'date',
      'salaryBangladesh',
      'fuelCost',
      'compoundInterest',
      'scientific',
    ]

    implementedFormulas.forEach((formula) => {
      expect(isFormulaImplemented(formula)).toBe(true)
    })
  })

  it('should return error for unimplemented formulas', () => {
    const result = executeFormula('nonexistent', {})
    expect(result.success).toBe(false)
    expect(result.error).toContain('not yet implemented')
  })
})

describe('Mortgage Calculator', () => {
  it('should calculate monthly payment correctly', () => {
    const result = calculateMortgage({
      homePrice: 300000,
      downPayment: 60000,
      interestRate: 6.5,
      loanTerm: 30,
      propertyTax: 0,
      homeInsurance: 0,
    })

    expect(result.success).toBe(true)
    expect(result.outputs.loanAmount).toBe(240000)
    // Monthly payment for $240,000 at 6.5% for 30 years
    expect(result.outputs.monthlyPayment).toBeCloseTo(1516.57, 0)
  })

  it('should include taxes and insurance in total monthly', () => {
    const result = calculateMortgage({
      homePrice: 300000,
      downPayment: 60000,
      interestRate: 6.5,
      loanTerm: 30,
      propertyTax: 3600,
      homeInsurance: 1200,
    })

    expect(result.success).toBe(true)
    const monthlyTaxes = 3600 / 12
    const monthlyInsurance = 1200 / 12
    expect(result.outputs.totalMonthlyPayment).toBeCloseTo(
      (result.outputs.monthlyPayment as number) + monthlyTaxes + monthlyInsurance,
      0
    )
  })

  it('should handle 0% interest rate', () => {
    const result = calculateMortgage({
      homePrice: 120000,
      downPayment: 0,
      interestRate: 0,
      loanTerm: 10,
      propertyTax: 0,
      homeInsurance: 0,
    })

    expect(result.success).toBe(true)
    // $120,000 / 120 months = $1,000/month
    expect(result.outputs.monthlyPayment).toBe(1000)
  })
})

describe('Loan Calculator', () => {
  it('should calculate standard loan payment', () => {
    const result = calculateLoan({
      loanAmount: 25000,
      interestRate: 8.5,
      loanTerm: 60,
    })

    expect(result.success).toBe(true)
    expect(result.outputs.monthlyPayment).toBeCloseTo(511.91, 0)
  })

  it('should calculate total interest correctly', () => {
    const result = calculateLoan({
      loanAmount: 10000,
      interestRate: 10,
      loanTerm: 12,
    })

    expect(result.success).toBe(true)
    const totalPayment = result.outputs.totalPayment as number
    expect(result.outputs.totalInterest).toBeCloseTo(totalPayment - 10000, 0)
  })
})

describe('Auto Loan Calculator', () => {
  it('should include sales tax in loan amount', () => {
    const result = calculateAutoLoan({
      vehiclePrice: 35000,
      downPayment: 5000,
      tradeInValue: 0,
      interestRate: 6.9,
      loanTerm: 60,
      salesTaxRate: 7,
    })

    expect(result.success).toBe(true)
    // Loan = 35000 + (35000 * 0.07) - 5000 = 32450
    expect(result.outputs.loanAmount).toBeCloseTo(32450, 0)
  })

  it('should account for trade-in value', () => {
    const result = calculateAutoLoan({
      vehiclePrice: 30000,
      downPayment: 5000,
      tradeInValue: 5000,
      interestRate: 5,
      loanTerm: 48,
      salesTaxRate: 0,
    })

    expect(result.success).toBe(true)
    // Loan = 30000 - 5000 - 5000 = 20000
    expect(result.outputs.loanAmount).toBe(20000)
  })
})

describe('BMI Calculator', () => {
  it('should calculate BMI correctly for imperial units', () => {
    const result = calculateBMI({
      unit: 'imperial',
      weight: 150,
      heightFeet: 5,
      heightInches: 10,
    })

    expect(result.success).toBe(true)
    // BMI = (150 * 703) / (70^2) = 21.5
    expect(result.outputs.bmi).toBeCloseTo(21.5, 0)
    expect(result.outputs.category).toBe('Normal weight')
  })

  it('should calculate BMI correctly for metric units', () => {
    const result = calculateBMI({
      unit: 'metric',
      weight: 70,
      heightCm: 175,
    })

    expect(result.success).toBe(true)
    // BMI = 70 / (1.75^2) = 22.86
    expect(result.outputs.bmi).toBeCloseTo(22.9, 0)
    expect(result.outputs.category).toBe('Normal weight')
  })

  it('should categorize BMI correctly', () => {
    const underweight = calculateBMI({ unit: 'metric', weight: 50, heightCm: 175 })
    expect(underweight.outputs.category).toBe('Underweight')

    const overweight = calculateBMI({ unit: 'metric', weight: 85, heightCm: 175 })
    expect(overweight.outputs.category).toBe('Overweight')

    const obese = calculateBMI({ unit: 'metric', weight: 100, heightCm: 175 })
    expect(obese.outputs.category).toContain('Obese')
  })
})

describe('Age Calculator', () => {
  it('should calculate age correctly', () => {
    const result = calculateAge({
      birthDate: '1990-01-15',
      targetDate: '2024-01-15',
    })

    expect(result.success).toBe(true)
    expect(result.outputs.ageYears).toBe(34)
  })

  it('should calculate detailed age breakdown', () => {
    const result = calculateAge({
      birthDate: '1990-06-15',
      targetDate: '2024-12-01',
    })

    expect(result.success).toBe(true)
    expect(result.outputs.ageYears).toBe(34)
    expect(result.outputs.ageDetailed).toContain('34 years')
    expect(result.outputs.ageDetailed).toContain('months')
  })

  it('should calculate days until next birthday', () => {
    const result = calculateAge({
      birthDate: '1990-12-25',
      targetDate: '2024-12-01',
    })

    expect(result.success).toBe(true)
    expect(result.outputs.daysUntilBirthday).toBe(24) // Dec 1 to Dec 25
  })

  it('should handle invalid birth date', () => {
    const result = calculateAge({
      birthDate: 'invalid',
    })

    expect(result.success).toBe(false)
    expect(result.error).toBe('Invalid birth date')
  })
})

describe('Date Calculator', () => {
  it('should calculate days between dates', () => {
    const result = calculateDate({
      mode: 'difference',
      startDate: '2024-01-01',
      endDate: '2024-12-31',
      includeEndDate: 'yes',
    })

    expect(result.success).toBe(true)
    expect(result.outputs.totalDays).toBe(366) // 2024 is a leap year
  })

  it('should add days to date', () => {
    const result = calculateDate({
      mode: 'add',
      startDate: '2024-01-01',
      daysToAdd: 30,
    })

    expect(result.success).toBe(true)
    expect(result.outputs.resultDate).toBe('2024-01-31')
  })

  it('should subtract days from date', () => {
    const result = calculateDate({
      mode: 'add',
      startDate: '2024-01-31',
      daysToAdd: -30,
    })

    expect(result.success).toBe(true)
    expect(result.outputs.resultDate).toBe('2024-01-01')
  })

  it('should count weekdays and weekends', () => {
    const result = calculateDate({
      mode: 'difference',
      startDate: '2024-01-01', // Monday
      endDate: '2024-01-07', // Sunday
      includeEndDate: 'no',
    })

    expect(result.success).toBe(true)
    expect(result.outputs.weekdays).toBe(5)
    expect(result.outputs.weekends).toBe(1)
  })
})

describe('Salary Calculator (Bangladesh)', () => {
  it('should calculate net salary correctly', () => {
    const result = calculateSalaryBangladesh({
      grossSalary: 50000,
      basicPercentage: 60,
      pfContribution: 10,
      taxArea: 'dhaka',
      gender: 'male',
      hasDisability: 'no',
    })

    expect(result.success).toBe(true)
    expect(result.outputs.basicSalary).toBe(30000)
    expect(result.outputs.pfDeduction).toBe(3000) // 10% of basic
    expect(result.outputs.yearlyGross).toBe(600000)
  })

  it('should apply higher tax exemption for females', () => {
    const maleResult = calculateSalaryBangladesh({
      grossSalary: 50000,
      basicPercentage: 60,
      pfContribution: 0,
      taxArea: 'dhaka',
      gender: 'male',
      hasDisability: 'no',
    })

    const femaleResult = calculateSalaryBangladesh({
      grossSalary: 50000,
      basicPercentage: 60,
      pfContribution: 0,
      taxArea: 'dhaka',
      gender: 'female',
      hasDisability: 'no',
    })

    expect(femaleResult.success).toBe(true)
    // Female should pay less tax due to higher exemption
    expect(femaleResult.outputs.yearlyTax as number).toBeLessThanOrEqual(maleResult.outputs.yearlyTax as number)
  })
})

describe('Fuel Cost Calculator', () => {
  it('should calculate fuel cost for one-way trip (imperial)', () => {
    const result = calculateFuelCost({
      unit: 'imperial',
      distance: 100,
      fuelEfficiency: 25,
      fuelPrice: 3.50,
      roundTrip: 'no',
      passengers: 1,
    })

    expect(result.success).toBe(true)
    // 100 miles / 25 mpg = 4 gallons * $3.50 = $14
    expect(result.outputs.fuelNeeded).toBe(4)
    expect(result.outputs.totalCost).toBe(14)
  })

  it('should double distance for round trip', () => {
    const oneWay = calculateFuelCost({
      unit: 'imperial',
      distance: 100,
      fuelEfficiency: 25,
      fuelPrice: 3.50,
      roundTrip: 'no',
      passengers: 1,
    })

    const roundTrip = calculateFuelCost({
      unit: 'imperial',
      distance: 100,
      fuelEfficiency: 25,
      fuelPrice: 3.50,
      roundTrip: 'yes',
      passengers: 1,
    })

    expect(roundTrip.outputs.totalCost).toBe((oneWay.outputs.totalCost as number) * 2)
  })

  it('should calculate cost per person', () => {
    const result = calculateFuelCost({
      unit: 'imperial',
      distance: 100,
      fuelEfficiency: 25,
      fuelPrice: 3.50,
      roundTrip: 'no',
      passengers: 4,
    })

    expect(result.success).toBe(true)
    // Total $14 / 4 passengers = $3.50 each
    expect(result.outputs.costPerPerson).toBe(3.5)
  })

  it('should calculate for metric units', () => {
    const result = calculateFuelCost({
      unit: 'metric',
      distance: 100,
      fuelEfficiency: 8, // L/100km
      fuelPrice: 1.50,
      roundTrip: 'no',
      passengers: 1,
    })

    expect(result.success).toBe(true)
    // 100km * (8/100) = 8 liters * $1.50 = $12
    expect(result.outputs.fuelNeeded).toBe(8)
    expect(result.outputs.totalCost).toBe(12)
  })
})

describe('Compound Interest Calculator', () => {
  it('should calculate compound interest correctly', () => {
    const result = calculateCompoundInterest({
      principal: 10000,
      monthlyContribution: 0,
      interestRate: 5,
      years: 10,
      compoundFrequency: 'annually',
    })

    expect(result.success).toBe(true)
    // 10000 * (1.05)^10 = 16288.95
    expect(result.outputs.futureValue).toBeCloseTo(16288.95, 0)
  })

  it('should include monthly contributions', () => {
    const result = calculateCompoundInterest({
      principal: 0,
      monthlyContribution: 100,
      interestRate: 5,
      years: 10,
      compoundFrequency: 'monthly',
    })

    expect(result.success).toBe(true)
    expect(result.outputs.totalContributions).toBe(12000) // 100 * 12 * 10
    expect(result.outputs.futureValue as number).toBeGreaterThan(12000) // Should have interest
  })

  it('should calculate effective annual rate', () => {
    const result = calculateCompoundInterest({
      principal: 10000,
      monthlyContribution: 0,
      interestRate: 12,
      years: 1,
      compoundFrequency: 'monthly',
    })

    expect(result.success).toBe(true)
    // Effective rate for 12% compounded monthly ≈ 12.68%
    expect(result.outputs.effectiveRate).toBeCloseTo(12.68, 1)
  })
})

describe('Scientific Calculator', () => {
  it('should evaluate basic arithmetic', () => {
    expect(calculateScientific({ expression: '2 + 3', angleMode: 'degrees' }).outputs.result).toBe(5)
    expect(calculateScientific({ expression: '10 - 4', angleMode: 'degrees' }).outputs.result).toBe(6)
    expect(calculateScientific({ expression: '3 * 4', angleMode: 'degrees' }).outputs.result).toBe(12)
    expect(calculateScientific({ expression: '15 / 3', angleMode: 'degrees' }).outputs.result).toBe(5)
  })

  it('should handle exponents', () => {
    const result = calculateScientific({
      expression: '2^8',
      angleMode: 'degrees',
    })

    expect(result.success).toBe(true)
    expect(result.outputs.result).toBe(256)
  })

  it('should evaluate trigonometric functions in degrees', () => {
    const sin30 = calculateScientific({ expression: 'sin(30)', angleMode: 'degrees' })
    expect(sin30.outputs.result).toBeCloseTo(0.5, 5)

    const cos60 = calculateScientific({ expression: 'cos(60)', angleMode: 'degrees' })
    expect(cos60.outputs.result).toBeCloseTo(0.5, 5)
  })

  it('should evaluate logarithms', () => {
    const log100 = calculateScientific({ expression: 'log(100)', angleMode: 'degrees' })
    expect(log100.outputs.result).toBe(2)

    const lnE = calculateScientific({ expression: 'ln(e)', angleMode: 'degrees' })
    expect(lnE.outputs.result).toBeCloseTo(1, 5)
  })

  it('should handle sqrt', () => {
    const result = calculateScientific({ expression: 'sqrt(144)', angleMode: 'degrees' })
    expect(result.outputs.result).toBe(12)
  })

  it('should handle pi constant', () => {
    const result = calculateScientific({ expression: 'pi', angleMode: 'degrees' })
    expect(result.outputs.result).toBeCloseTo(3.14159, 4)
  })

  it('should return error for empty expression', () => {
    const result = calculateScientific({ expression: '', angleMode: 'degrees' })
    expect(result.success).toBe(false)
  })

  it('should handle complex expressions', () => {
    const result = calculateScientific({
      expression: 'sqrt(16) + 2^3 - 10/2',
      angleMode: 'degrees',
    })

    expect(result.success).toBe(true)
    // sqrt(16) = 4, 2^3 = 8, 10/2 = 5, so 4 + 8 - 5 = 7
    expect(result.outputs.result).toBe(7)
  })
})
