import { describe, it, expect } from 'vitest';
import {
  formatCurrency,
  formatNumber,
  formatPercentage,
  formatDate,
  parseCurrency,
  parsePercentage,
  slugify,
  capitalize,
  truncate,
  daysBetween,
  getOrdinal,
  generateEmbedCode,
  cn,
} from '../lib/utils';

describe('formatCurrency', () => {
  it('should format USD currency', () => {
    expect(formatCurrency(1234.56)).toBe('$1,234.56');
    expect(formatCurrency(0)).toBe('$0.00');
    expect(formatCurrency(1000000)).toBe('$1,000,000.00');
  });

  it('should handle different currencies', () => {
    expect(formatCurrency(1234.56, 'EUR', 'de-DE')).toContain('1.234,56');
  });
});

describe('formatNumber', () => {
  it('should format numbers with commas', () => {
    expect(formatNumber(1234567.89)).toBe('1,234,567.89');
  });

  it('should respect decimal places', () => {
    expect(formatNumber(123.456, 0)).toBe('123');
    expect(formatNumber(123.456, 4)).toBe('123.4560');
  });
});

describe('formatPercentage', () => {
  it('should format percentages', () => {
    expect(formatPercentage(50)).toBe('50.00%');
    expect(formatPercentage(33.333, 1)).toBe('33.3%');
  });
});

describe('formatDate', () => {
  it('should format dates', () => {
    const date = new Date('2024-01-15');
    const formatted = formatDate(date);
    expect(formatted).toContain('January');
    expect(formatted).toContain('15');
    expect(formatted).toContain('2024');
  });
});

describe('parseCurrency', () => {
  it('should parse currency strings', () => {
    expect(parseCurrency('$1,234.56')).toBe(1234.56);
    expect(parseCurrency('$0.00')).toBe(0);
    expect(parseCurrency('invalid')).toBe(0);
  });
});

describe('parsePercentage', () => {
  it('should parse percentage strings', () => {
    expect(parsePercentage('50%')).toBe(50);
    expect(parsePercentage('33.5')).toBe(33.5);
  });
});

describe('slugify', () => {
  it('should create URL-friendly slugs', () => {
    expect(slugify('Hello World')).toBe('hello-world');
    expect(slugify('BMI Calculator')).toBe('bmi-calculator');
    expect(slugify('Test  Multiple   Spaces')).toBe('test-multiple-spaces');
  });

  it('should remove special characters', () => {
    expect(slugify('Price: $100!')).toBe('price-100');
  });
});

describe('capitalize', () => {
  it('should capitalize first letter', () => {
    expect(capitalize('hello')).toBe('Hello');
    expect(capitalize('HELLO')).toBe('HELLO');
  });
});

describe('truncate', () => {
  it('should truncate long text', () => {
    expect(truncate('Hello World', 5)).toBe('Hello...');
    expect(truncate('Hi', 10)).toBe('Hi');
  });
});

describe('daysBetween', () => {
  it('should calculate days between dates', () => {
    const date1 = new Date('2024-01-01');
    const date2 = new Date('2024-01-31');
    expect(daysBetween(date1, date2)).toBe(30);
  });

  it('should handle reverse order', () => {
    const date1 = new Date('2024-01-31');
    const date2 = new Date('2024-01-01');
    expect(daysBetween(date1, date2)).toBe(30);
  });
});

describe('getOrdinal', () => {
  it('should return correct ordinal suffixes', () => {
    expect(getOrdinal(1)).toBe('1st');
    expect(getOrdinal(2)).toBe('2nd');
    expect(getOrdinal(3)).toBe('3rd');
    expect(getOrdinal(4)).toBe('4th');
    expect(getOrdinal(11)).toBe('11th');
    expect(getOrdinal(12)).toBe('12th');
    expect(getOrdinal(13)).toBe('13th');
    expect(getOrdinal(21)).toBe('21st');
    expect(getOrdinal(22)).toBe('22nd');
    expect(getOrdinal(23)).toBe('23rd');
  });
});

describe('generateEmbedCode', () => {
  it('should generate valid iframe code', () => {
    const code = generateEmbedCode('mortgage', 'https://microcalc.com', 400, 600);
    expect(code).toContain('iframe');
    expect(code).toContain('src="https://microcalc.com/embed/mortgage"');
    expect(code).toContain('width="400"');
    expect(code).toContain('height="600"');
  });
});

describe('cn (className utility)', () => {
  it('should merge class names', () => {
    expect(cn('foo', 'bar')).toBe('foo bar');
    expect(cn('foo', undefined, 'bar')).toBe('foo bar');
    expect(cn('foo', false && 'bar', 'baz')).toBe('foo baz');
  });
});

