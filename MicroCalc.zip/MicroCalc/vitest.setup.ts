import { expect, afterEach } from 'vitest';

// Clean up after each test
afterEach(() => {
  // Clean up any side effects
});

// Custom matchers can be added here if needed

